"""
Laboratorio MÍNIMO y deliberadamente vulnerable para validar el auditor.
SOLO escucha en 127.0.0.1:5001. No lo expongas a internet ni a tu red.

  Login:      admin / admin   (formulario con token oculto, como DVWA)
  /search     XSS reflejado (sin escapar)
  /item?id=   SQLi con mensaje de error del motor (SQLite)
  /go?next=   Open redirect
  /safe       Control negativo: escapa la salida (NO debe dar hallazgos)
"""
import html
import secrets
import sqlite3
from flask import Flask, request, redirect, make_response

app = Flask(__name__)
SESSIONS = set()
db = sqlite3.connect(":memory:", check_same_thread=False)
db.execute("CREATE TABLE items(id INTEGER, name TEXT)")
db.executemany("INSERT INTO items VALUES(?,?)", [(1, "Semillas de tomate"), (2, "Semillas de lechuga")])

def logged(req):
    return req.cookies.get("lab_session") in SESSIONS

@app.route("/")
def index():
    if logged(request):
        return redirect("/home")
    return '<h1>Lab vulnerable</h1><a href="/login">Entrar</a>'

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form.get("username") == "admin" and request.form.get("password") == "admin" and request.form.get("user_token"):
            sid = secrets.token_hex(8); SESSIONS.add(sid)
            r = make_response(redirect("/home")); r.set_cookie("lab_session", sid)   # sin HttpOnly a propósito
            return r
        return '<form method="post"><input name="username"><input type="password" name="password"><input type="hidden" name="user_token" value="x"><p>Error</p></form>'
    return '<form method="post" action="/login"><input name="username"><input type="password" name="password"><input type="hidden" name="user_token" value="%s"><input type="submit" name="Login" value="Login"></form>' % secrets.token_hex(4)

@app.route("/home")
def home():
    if not logged(request):
        return redirect("/login")
    return ('<h1>Panel</h1><a href="/search?q=hola">Buscar</a> <a href="/item?id=1">Producto</a> '
            '<a href="/go?next=/home">Ir</a> <a href="/safe?q=a">Seguro</a> <a href="/logout">Salir</a>')

@app.route("/search")
def search():
    if not logged(request): return redirect("/login")
    return "<h2>Resultados para: %s</h2>" % request.args.get("q", "")           # XSS

@app.route("/item")
def item():
    if not logged(request): return redirect("/login")
    pid = request.args.get("id", "1")
    try:
        rows = db.execute("SELECT name FROM items WHERE id = '%s'" % pid).fetchall()   # SQLi
        return "<p>%s</p>" % (rows[0][0] if rows else "sin resultados")
    except Exception as e:
        return "<pre>sqlite3.OperationalError: %s</pre>" % html.escape(str(e)), 500

@app.route("/go")
def go():
    if not logged(request): return redirect("/login")
    return redirect(request.args.get("next", "/"))                              # Open redirect

@app.route("/safe")
def safe():
    if not logged(request): return redirect("/login")
    return "<p>Eco seguro: %s</p>" % html.escape(request.args.get("q", ""))

@app.route("/logout")
def logout():
    SESSIONS.discard(request.cookies.get("lab_session")); return redirect("/")

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5001, debug=False)
