@echo off
title CyberSec Audit Engine - Consola del Servidor
echo =====================================================================
echo  ⚡ CYBERSEC AUDIT ENGINE - PLATAFORMA DE AUDITORIA DE SEGURIDAD ⚡
echo =====================================================================
echo  Iniciando el servidor web de la aplicacion en http://127.0.0.1:5000 ...
echo  Presione Ctrl+C para detener el servidor.
echo =====================================================================
python app.py
pause
