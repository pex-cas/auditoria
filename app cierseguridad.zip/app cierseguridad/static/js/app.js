// CYBERSEC AUDIT PLATFORM - FRONTEND CONTROLLER
let activeReport = null;
let currentFindings = [];
let currentFilterSeverity = 'all';
let currentFilterStatus = 'all';
let sseSource = null;

document.addEventListener("DOMContentLoaded", () => {
    initSSE();
    setupNavigation();
    setupAuditForm();
    loadTaxonomy();
    loadHistory();
});

// 1. REAL-TIME SERVER-SENT EVENTS (SSE) LISTENER
function initSSE() {
    if (sseSource) {
        sseSource.close();
    }
    sseSource = new EventSource("/api/stream");

    sseSource.onmessage = (event) => {
        try {
            const data = JSON.parse(event.data);
            appendLog(data.timestamp, data.level, data.message);
            if (data.meta && data.meta.progress !== undefined) {
                updateProgress(data.meta.progress, data.message);
                if (data.meta.progress === 100) {
                    onScanCompleted();
                }
            }
        } catch (e) {
            // Heartbeat ping
        }
    };

    sseSource.onerror = () => {
        // Reconnect automatically
    };
}

function appendLog(time, level, message) {
    const logsContainer = document.getElementById("terminalLogs");
    if (!logsContainer) return;

    const div = document.createElement("div");
    div.className = `log-entry log-${level}`;
    div.innerHTML = `<span class="log-time">[${time}]</span> <span class="log-level">[${level}]</span> ${escapeHtml(message)}`;
    logsContainer.appendChild(div);
    logsContainer.scrollTop = logsContainer.scrollHeight;
}

function updateProgress(percent, label) {
    const progressCard = document.getElementById("progressCard");
    const progressBar = document.getElementById("progressBarFill");
    const progressPercent = document.getElementById("progressPercent");
    const progressStatus = document.getElementById("progressStatus");

    if (progressCard) progressCard.classList.add("active");
    if (progressBar) progressBar.style.width = `${percent}%`;
    if (progressPercent) progressPercent.innerText = `${percent}%`;
    if (progressStatus && label) progressStatus.innerText = label;
}

// 2. AUDIT TRIGGER & CONTROLS
function setupAuditForm() {
    const form = document.getElementById("auditForm");
    const startBtn = document.getElementById("startScanBtn");

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const urlInput = document.getElementById("targetUrl").value.trim();
        const consent = document.getElementById("consentCheckbox").checked;
        const mode = document.getElementById("scanMode").value;
        const rateLimit = document.getElementById("rateLimit").value;

        if (!urlInput) {
            alert("Por favor ingrese una URL válida.");
            return;
        }

        if (!consent) {
            alert("Debe certificar autorización explícita o propiedad del sitio para fines de auditoría ética.");
            return;
        }

        startBtn.disabled = true;
        startBtn.innerHTML = `<span>⏳ Analizando...</span>`;
        document.getElementById("terminalLogs").innerHTML = "";
        updateProgress(5, "Iniciando auditoría...");

        try {
            const resp = await fetch("/api/scan", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    target_url: urlInput,
                    authorized_consent: consent,
                    scan_mode: mode,
                    max_requests_per_sec: parseFloat(rateLimit),
                    timeout_sec: 10,
                    max_duration_sec: 300,
                    crawl_depth: 3,
                    max_pages: 80,
                    deep_exposure_check: true,
                    cookies: (document.getElementById("advCookies") || {}).value || "",
                    extra_headers: (document.getElementById("advHeaders") || {}).value || "",
                    login_url: (document.getElementById("advLoginUrl") || {}).value || "",
                    login_username: (document.getElementById("advLoginUser") || {}).value || "",
                    login_password: (document.getElementById("advLoginPass") || {}).value || "",
                    login_user_field: (document.getElementById("advUserField") || {}).value || "username",
                    login_pass_field: (document.getElementById("advPassField") || {}).value || "password",
                    seed_urls: (document.getElementById("advSeeds") || {}).value || "",
                    test_post_forms: !!(document.getElementById("advPost") || {}).checked
                })
            });

            const data = await resp.json();
            if (!resp.ok) {
                alert(data.error || "Error al iniciar el análisis");
                startBtn.disabled = false;
                startBtn.innerHTML = `<span>⚡ Iniciar Auditoría</span>`;
            }
        } catch (err) {
            alert("Error de conexión con el motor de auditoría.");
            startBtn.disabled = false;
            startBtn.innerHTML = `<span>⚡ Iniciar Auditoría</span>`;
        }
    });
}

async function onScanCompleted() {
    const startBtn = document.getElementById("startScanBtn");
    if (startBtn) {
        startBtn.disabled = false;
        startBtn.innerHTML = `<span>⚡ Iniciar Auditoría</span>`;
    }

    // Fetch the latest generated report
    try {
        const resp = await fetch("/api/report/latest");
        if (resp.ok) {
            const report = await resp.json();
            renderReport(report);
            loadHistory();
        }
    } catch (e) {
        console.error("Error al obtener el reporte:", e);
    }
}

// 3. RENDER AUDIT RESULTS & METRICS
function renderReport(report) {
    activeReport = report;
    currentFindings = report.findings || [];

    // Header & Target Info
    document.getElementById("targetInfoDomain").innerText = report.domain;
    document.getElementById("targetInfoUrl").innerText = report.target_url;
    document.getElementById("targetInfoDuration").innerText = `${report.duration_seconds.toFixed(2)}s`;
    document.getElementById("targetInfoDate").innerText = report.start_time.replace("T", " ");

    const summary = report.summary || {};
    const counts = summary.counts || {};
    const score = summary.security_score !== undefined ? summary.security_score : 100;

    // Score display
    const scoreEl = document.getElementById("metricScore");
    const scoreColor = score < 50 ? "var(--sev-crit)" : (score < 80 ? "var(--sev-med)" : "var(--accent-emerald)");
    if (scoreEl) {
        scoreEl.innerText = score;
        scoreEl.style.color = scoreColor;
    }
    const scoreRating = document.getElementById("metricRating");
    if (scoreRating) scoreRating.innerText = summary.rating || "ACEPTABLE";

    // Stats Grid
    document.getElementById("statCrit").innerText = counts.critical || 0;
    document.getElementById("statHigh").innerText = counts.high || 0;
    document.getElementById("statMed").innerText = counts.medium || 0;
    document.getElementById("statLow").innerText = counts.low || 0;
    document.getElementById("statConfirmed").innerText = counts.confirmed || 0;
    document.getElementById("statTech").innerText = (report.technologies || []).length;

    // Render Technologies
    renderTechnologies(report.technologies || []);

    // Render Findings
    applyFindingsFilter();

    // Show Export Buttons
    const exportBar = document.getElementById("exportBar");
    if (exportBar) exportBar.style.display = "flex";
}

function renderTechnologies(technologies) {
    const container = document.getElementById("techCardsGrid");
    if (!container) return;

    if (!technologies || technologies.length === 0) {
        container.innerHTML = `<div style="color: var(--text-dim); padding: 10px;">No se identificaron tecnologías específicas en las cabeceras o código analizado.</div>`;
        return;
    }

    container.innerHTML = technologies.map(t => `
        <div class="tech-box">
            <div class="tech-box-header">
                <span class="tech-box-name">${escapeHtml(t.name)}</span>
                ${t.version ? `<span class="tech-box-ver">${escapeHtml(t.version)}</span>` : ''}
            </div>
            <div class="tech-box-cat">${escapeHtml(t.category)}</div>
            ${t.evidence ? `<div class="tech-box-evidence">${escapeHtml(t.evidence)}</div>` : ''}
        </div>
    `).join('');
}

function applyFindingsFilter() {
    const container = document.getElementById("findingsList");
    const searchVal = (document.getElementById("findingSearchInput")?.value || "").toLowerCase();

    let filtered = currentFindings.filter(f => {
        // Severity filter
        if (currentFilterSeverity !== 'all' && f.severity.toLowerCase() !== currentFilterSeverity.toLowerCase()) {
            return false;
        }
        // Status filter
        if (currentFilterStatus !== 'all' && f.status !== currentFilterStatus) {
            return false;
        }
        // Search text
        if (searchVal) {
            const matchText = (f.title + f.affected_component + f.technical_description + f.remediation).toLowerCase();
            return matchText.includes(searchVal);
        }
        return true;
    });

    if (filtered.length === 0) {
        container.innerHTML = `<div style="color: var(--text-dim); padding: 20px; text-align: center;">No hay hallazgos que coincidan con los filtros aplicados.</div>`;
        return;
    }

    container.innerHTML = filtered.map((f, idx) => {
        const sevClass = `sev-${f.severity.toLowerCase()}`;
        let badgeClass = "badge-info";
        if (f.severity === "CRÍTICA") badgeClass = "badge-crit";
        else if (f.severity === "ALTA") badgeClass = "badge-high";
        else if (f.severity === "MEDIA") badgeClass = "badge-med";
        else if (f.severity === "BAJA") badgeClass = "badge-low";

        return `
        <div class="finding-item ${sevClass}" onclick="openFindingModal('${escapeHtml(f.id)}')">
            <div class="finding-top">
                <span class="finding-badge ${badgeClass}">${f.severity}</span>
                <span class="finding-title-text">#${f.vuln_number} ${escapeHtml(f.title)}</span>
                <span class="finding-status-tag">${escapeHtml(f.status)}</span>
            </div>
            <div class="finding-item-meta">
                <span><strong>Componente:</strong> <code>${escapeHtml(f.affected_component)}</code></span>
                <span><strong>Categoría:</strong> ${escapeHtml(f.category)}</span>
            </div>
        </div>
        `;
    }).join('');
}

// 4. FINDING DETAIL MODAL
function openFindingModal(findingId) {
    const finding = currentFindings.find(f => f.id === findingId);
    if (!finding) return;

    const modal = document.getElementById("findingModal");
    document.getElementById("modalVulnNum").innerText = `#${finding.vuln_number}`;
    document.getElementById("modalTitle").innerText = finding.title;
    document.getElementById("modalSeverity").innerText = finding.severity;
    document.getElementById("modalStatus").innerText = finding.status;
    document.getElementById("modalComponent").innerText = finding.affected_component;
    document.getElementById("modalCategory").innerText = finding.category;
    document.getElementById("modalDescription").innerText = finding.technical_description;
    document.getElementById("modalEvidence").innerText = finding.evidence || "Sin evidencia directa";
    document.getElementById("modalImpact").innerText = finding.impact;
    document.getElementById("modalRemediation").innerText = finding.remediation;

    modal.classList.add("active");
}

function closeFindingModal() {
    document.getElementById("findingModal")?.classList.remove("active");
}

// 5. TAXONOMY 300 EXPLORER
async function loadTaxonomy() {
    try {
        const resp = await fetch("/api/taxonomy");
        if (resp.ok) {
            const list = await resp.json();
            const tbody = document.getElementById("taxonomyTableBody");
            if (!tbody) return;

            tbody.innerHTML = list.map(item => `
                <tr>
                    <td style="font-family: var(--font-mono); font-weight: bold; color: var(--accent-cyan);">#${item.number}</td>
                    <td><strong>${escapeHtml(item.title)}</strong></td>
                    <td><span style="font-size: 11px; color: var(--text-muted);">${escapeHtml(item.chapter)}</span></td>
                    <td><code>${escapeHtml(item.cwe || 'CWE')}</code></td>
                    <td style="font-size: 12px; color: var(--text-muted);">${escapeHtml(item.component)}</td>
                    <td><button class="filter-btn" onclick="showTaxonomyInfo(${item.number})">Detalles</button></td>
                </tr>
            `).join('');
        }
    } catch (e) {
        console.error("Error al cargar taxonomía:", e);
    }
}

async function showTaxonomyInfo(num) {
    try {
        const resp = await fetch("/api/taxonomy");
        const list = await resp.json();
        const item = list.find(x => x.number === num);
        if (item) {
            alert(`[#${item.number}] ${item.title}\n\nCapítulo: ${item.chapter}\nCWE: ${item.cwe}\nOWASP: ${item.owasp}\n\nDescripción:\n${item.description}\n\nImpacto:\n${item.impact}\n\nMitigación:\n${item.remediation}`);
        }
    } catch (e) {}
}

// 6. HISTORY OF AUDITS
async function loadHistory() {
    try {
        const resp = await fetch("/api/history");
        if (resp.ok) {
            const list = await resp.json();
            const container = document.getElementById("historyListContainer");
            if (!container) return;

            if (list.length === 0) {
                container.innerHTML = `<div style="color: var(--text-dim); padding: 15px;">No hay reportes de auditorías previas registradas.</div>`;
                return;
            }

            container.innerHTML = list.map(item => `
                <div class="finding-item" style="border-left-color: var(--accent-cyan); display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <div style="font-size: 15px; font-weight: 700; color: #fff;">${escapeHtml(item.domain)} <span style="font-size: 11px; color: var(--text-dim);">(${item.scan_id})</span></div>
                        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">
                            Fecha: ${item.start_time.replace("T", " ")} | Duración: ${item.duration_seconds.toFixed(1)}s | Score: <strong>${item.security_score}/100</strong>
                        </div>
                    </div>
                    <div style="display: flex; gap: 8px;">
                        <a href="/api/report/${item.scan_id}/html" target="_blank" class="btn-secondary" style="text-decoration: none; font-size: 12px;">Ver Reporte HTML/PDF</a>
                        <a href="/api/report/${item.scan_id}/json" class="btn-secondary" style="text-decoration: none; font-size: 12px;">JSON</a>
                    </div>
                </div>
            `).join('');
        }
    } catch (e) {
        console.error("Error al cargar historial:", e);
    }
}

// 7. EXPORT ACTIONS
function downloadActiveJson() {
    if (!activeReport) return;
    window.location.href = `/api/report/${activeReport.scan_id}/json`;
}

function viewActiveHtml() {
    if (!activeReport) return;
    window.open(`/api/report/${activeReport.scan_id}/html`, '_blank');
}

// 8. NAVIGATION TABS
function setupNavigation() {
    const tabBtns = document.querySelectorAll(".nav-tab-btn");
    tabBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            tabBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            const target = btn.getAttribute("data-tab");
            document.querySelectorAll(".tab-content").forEach(tc => tc.classList.remove("active"));
            document.getElementById(target)?.classList.add("active");
        });
    });

    // Findings Filter buttons
    document.querySelectorAll(".filter-btn-sev").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".filter-btn-sev").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            currentFilterSeverity = btn.getAttribute("data-sev");
            applyFindingsFilter();
        });
    });

    document.querySelectorAll(".filter-btn-status").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".filter-btn-status").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            currentFilterStatus = btn.getAttribute("data-status");
            applyFindingsFilter();
        });
    });

    document.getElementById("findingSearchInput")?.addEventListener("input", () => {
        applyFindingsFilter();
    });
}

function escapeHtml(text) {
    if (!text) return "";
    return String(text)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
