"""
CyberSec Audit Engine - Web Dashboard and Application Server.
Provides a modern Cybersecurity Web UI, real-time SSE telemetry, and REST endpoints.
"""
import os
import json
import threading
import queue
import ipaddress
import urllib.parse
import threading
from typing import Dict, Any, Optional
from flask import Flask, render_template, request, jsonify, Response, send_file

from engine.models import ScanConfig, AuditReport
from engine.scanner import SecurityAuditScanner
from engine.reporter import ReportGenerator
from engine.logger import AuditLogger
from engine.knowledge_base import VULNERABILITIES_KB

app = Flask(__name__)
app.config['SECRET_KEY'] = 'cybersec-audit-engine-key-2026'

# Global state for active scans and logs
REPORTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "reports")
os.makedirs(REPORTS_DIR, exist_ok=True)
reporter = ReportGenerator(output_dir=REPORTS_DIR)

global_logger = AuditLogger()
scan_state_lock = threading.Lock()
current_scan_report: Optional[AuditReport] = None
is_scan_running = False

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/scan", methods=["POST"])
def start_scan():
    global is_scan_running, current_scan_report

    with scan_state_lock:
        if is_scan_running:
            return jsonify({"error": "Existe un análisis de seguridad en ejecución. Por favor espere a que finalice."}), 400

    data = request.json or {}
    target_url = data.get("target_url", "").strip()
    if not target_url:
        return jsonify({"error": "Debe especificar una URL válida para analizar."}), 400

    authorized_consent = data.get("authorized_consent", False)
    if not authorized_consent:
        return jsonify({"error": "Debe certificar autorización expresa o propiedad sobre el sitio para iniciar la auditoría ética."}), 400

    scan_mode = data.get("scan_mode", "active_safe")
    if scan_mode not in ("active_safe", "passive"):
        return jsonify({"error": "Modo de análisis no válido."}), 400

    # Los laboratorios locales pueden usar más velocidad; los hosts públicos
    # conservan un techo moderado aunque el cliente intente enviar otro valor.
    normalized_target = target_url if "://" in target_url else "https://" + target_url
    parsed_target = urllib.parse.urlsplit(normalized_target)
    if parsed_target.scheme not in ("http", "https") or not parsed_target.hostname:
        return jsonify({"error": "La URL debe ser HTTP o HTTPS y contener un hostname válido."}), 400
    host = parsed_target.hostname.lower()
    try:
        is_loopback = ipaddress.ip_address(host).is_loopback
    except ValueError:
        is_loopback = host == "localhost" or host.endswith(".localhost")

    try:
        requested_rate = float(data.get("max_requests_per_sec", 3.0))
        timeout = max(2, min(int(data.get("timeout_sec", 8)), 30))
        max_duration = max(30, min(int(data.get("max_duration_sec", 240)), 900))
    except (TypeError, ValueError):
        return jsonify({"error": "Los límites de tiempo y velocidad deben ser numéricos."}), 400
    max_rate = min(max(requested_rate, 0.2), 20.0 if is_loopback else 3.0)
    deep_exposure = bool(data.get("deep_exposure_check", True))

    seed_urls = [u.strip() for u in (data.get("seed_urls") or "").splitlines() if u.strip()] \
        if isinstance(data.get("seed_urls"), str) else list(data.get("seed_urls") or [])
    extra_headers = {}
    for line in (data.get("extra_headers") or "").splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            extra_headers[k.strip()] = v.strip()

    config = ScanConfig(
        target_url=target_url,
        scan_mode=scan_mode,
        max_requests_per_sec=max_rate,
        timeout_sec=timeout,
        max_duration_sec=max_duration,
        deep_exposure_check=deep_exposure,
        authorized_consent=True,
        seed_urls=seed_urls,
        cookies=(data.get("cookies") or "").strip(),
        extra_headers=extra_headers,
        login_url=(data.get("login_url") or "").strip(),
        login_username=(data.get("login_username") or "").strip(),
        login_password=data.get("login_password") or "",
        login_user_field=(data.get("login_user_field") or "username").strip(),
        login_pass_field=(data.get("login_pass_field") or "password").strip(),
        test_post_forms=bool(data.get("test_post_forms", False)),
        crawl_depth=max(0, min(int(data.get("crawl_depth", 3 if is_loopback else 2)), 5)),
        max_pages=max(1, min(int(data.get("max_pages", 80 if is_loopback else 40)), 200)),
    )

    def scan_worker():
        global is_scan_running, current_scan_report
        try:
            scanner = SecurityAuditScanner(config=config, logger=global_logger)
            report = scanner.run()
            current_scan_report = report
            # Automatically save report to disk
            reporter.export_json(report)
            reporter.export_html(report)
        except Exception as e:
            global_logger.log(f"Error crítico en ejecución del escáner: {str(e)}", "ERROR", {"progress": 100})
        finally:
            with scan_state_lock:
                is_scan_running = False

    with scan_state_lock:
        if is_scan_running:
            return jsonify({"error": "Ya hay una auditoría en ejecución."}), 409
        is_scan_running = True
    thread = threading.Thread(target=scan_worker, daemon=True)
    thread.start()

    return jsonify({
        "status": "started",
        "message": f"Auditoría iniciada correctamente sobre {target_url}",
        "target_url": target_url
    })

@app.route("/api/stream")
def sse_stream():
    """Server-Sent Events endpoint to stream real-time logs and progress to the UI."""
    q = global_logger.subscribe()

    def event_stream():
        try:
            while True:
                try:
                    event_data = q.get(timeout=25.0)
                    yield f"data: {json.dumps(event_data)}\n\n"
                except queue.Empty:
                    # Keep-alive heartbeat
                    yield f": ping\n\n"
        except GeneratorExit:
            global_logger.unsubscribe(q)

    return Response(event_stream(), mimetype="text/event-stream")

@app.route("/api/report/latest")
def get_latest_report():
    global current_scan_report
    if current_scan_report is None:
        return jsonify({"error": "No hay análisis disponible en la sesión actual."}), 404
    return jsonify(current_scan_report.to_dict())

@app.route("/api/report/<scan_id>/json")
def download_json_report(scan_id):
    filepath = os.path.join(REPORTS_DIR, f"{scan_id}.json")
    if os.path.exists(filepath):
        return send_file(filepath, mimetype="application/json", as_attachment=True, download_name=f"{scan_id}.json")
    return jsonify({"error": "Reporte no encontrado."}), 404

@app.route("/api/report/<scan_id>/html")
def view_html_report(scan_id):
    filepath = os.path.join(REPORTS_DIR, f"{scan_id}.html")
    if os.path.exists(filepath):
        return send_file(filepath, mimetype="text/html")
    return jsonify({"error": "Reporte HTML no encontrado."}), 404

@app.route("/api/history")
def get_history():
    history = []
    if os.path.exists(REPORTS_DIR):
        for fname in os.listdir(REPORTS_DIR):
            if fname.endswith(".json"):
                fpath = os.path.join(REPORTS_DIR, fname)
                try:
                    with open(fpath, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        history.append({
                            "scan_id": data.get("scan_id"),
                            "target_url": data.get("target_url"),
                            "domain": data.get("domain"),
                            "start_time": data.get("start_time"),
                            "duration_seconds": data.get("duration_seconds"),
                            "security_score": data.get("summary", {}).get("security_score", 100),
                            "findings_count": len(data.get("findings", [])),
                            "technologies_count": len(data.get("technologies", []))
                        })
                except Exception:
                    pass
    # Sort newest first
    history.sort(key=lambda x: x.get("start_time", ""), reverse=True)
    return jsonify(history)

@app.route("/api/taxonomy")
def get_taxonomy():
    """Returns the 300-entry security vulnerability taxonomy."""
    items = []
    for k, v in sorted(VULNERABILITIES_KB.items(), key=lambda x: x[0]):
        item = dict(v)
        item["number"] = k
        items.append(item)
    return jsonify(items)

if __name__ == "__main__":
    print("=" * 65)
    print(" ⚡ CYBERSEC AUDIT ENGINE - PLATAFORMA DE AUDITORÍA ÉTICA ⚡ ")
    print(" Servidor web activo en: http://127.0.0.1:5000")
    print(" Acceso a consola y dashboard en tiempo real disponible.")
    print("=" * 65)
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
