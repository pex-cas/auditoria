import sys
from engine.models import ScanConfig
from engine.scanner import SecurityAuditScanner
from engine.reporter import ReportGenerator

def test_scan():
    print("Iniciando prueba del motor sobre https://example.com ...")
    config = ScanConfig(
        target_url="https://example.com",
        scan_mode="passive",
        max_requests_per_sec=2.0,
        timeout_sec=6,
        authorized_consent=True
    )
    scanner = SecurityAuditScanner(config)
    report = scanner.run()
    print("Reporte generado exitosamente.")
    print(f"Dominio: {report.domain}")
    print(f"Duración: {report.duration_seconds:.2f}s")
    print(f"Puntuación de Seguridad: {report.summary['security_score']}/100")
    print(f"Total Hallazgos: {len(report.findings)}")
    print(f"Tecnologías Identificadas: {len(report.technologies)}")
    
    rep_gen = ReportGenerator()
    json_path = rep_gen.export_json(report)
    html_path = rep_gen.export_html(report)
    print(f"Exportado JSON: {json_path}")
    print(f"Exportado HTML: {html_path}")

if __name__ == "__main__":
    test_scan()
