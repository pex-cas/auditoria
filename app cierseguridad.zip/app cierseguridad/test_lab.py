"""
Valida el auditor contra el laboratorio local (lab/vuln_lab.py).
Uso:  python lab/vuln_lab.py   (en otra terminal)   y luego   python test_lab.py
"""
import sys, types
try:
    import dns.resolver  # noqa
except ImportError:      # permite correr el test aunque dnspython no esté instalado
    for n in ("dns", "dns.resolver", "dns.query", "dns.zone"):
        sys.modules[n] = types.ModuleType(n)

from engine.models import ScanConfig
from engine.scanner import SecurityAuditScanner

def run(label, **kw):
    cfg = ScanConfig(target_url="http://127.0.0.1:5001", scan_mode="active_safe", max_requests_per_sec=20,
                     timeout_sec=5, authorized_consent=True, check_tls=False, **kw)
    rep = SecurityAuditScanner(cfg).run()
    print(f"\n=== {label} ===")
    print("crawl:", rep.crawl_info)
    for f in rep.findings:
        if f.id.startswith(("XSS", "SQLI", "OPEN-REDIRECT")):
            print(f"  [{f.severity.value}/{f.status.value}] {f.title}  -> {f.affected_component}")
    return rep

if __name__ == "__main__":
    run("SIN login (antes de este arreglo era lo único que se veía)")
    run("CON login automático", login_url="http://127.0.0.1:5001/login", login_username="admin", login_password="admin")
