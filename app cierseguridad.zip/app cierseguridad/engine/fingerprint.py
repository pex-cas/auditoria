"""
Technology Fingerprinting Engine.
Detects Web Servers, Operating Systems, CMS platforms, Frameworks, and Runtimes.
Correlates identified versions with known vulnerability catalogues (CVE).
"""
import re
from typing import List, Dict, Any, Tuple
from bs4 import BeautifulSoup
from engine.models import TechFingerprint, Finding, Severity, FindingStatus
from engine.knowledge_base import VULNERABILITIES_KB

class TechnologyFingerprinter:
    def __init__(self, headers: Dict[str, str], html_content: str, cookies: Dict[str, str]):
        self.headers = {k.lower(): v for k, v in headers.items()}
        self.html_content = html_content or ""
        self.cookies = cookies or {}
        self.soup = BeautifulSoup(self.html_content, 'html.parser') if self.html_content else None

    def fingerprint(self) -> Tuple[List[TechFingerprint], List[Finding]]:
        technologies: List[TechFingerprint] = []
        findings: List[Finding] = []

        server_hdr = self.headers.get("server", "")
        powered_by = self.headers.get("x-powered-by", "")

        # --- 1. WEB SERVERS & PROXIES ---
        if "nginx" in server_hdr.lower():
            v_match = re.search(r"nginx/([\d\.]+)", server_hdr, re.IGNORECASE)
            version = v_match.group(1) if v_match else None
            technologies.append(TechFingerprint("Nginx", "Servidor Web / Proxy", version=version, evidence=f"Server: {server_hdr}"))
            if version:
                self._check_nginx_cves(version, findings)

        elif "apache" in server_hdr.lower():
            v_match = re.search(r"apache/([\d\.]+)", server_hdr, re.IGNORECASE)
            version = v_match.group(1) if v_match else None
            technologies.append(TechFingerprint("Apache HTTP Server", "Servidor Web", version=version, evidence=f"Server: {server_hdr}"))
            if version:
                self._check_apache_cves(version, findings)

        elif "microsoft-iis" in server_hdr.lower():
            v_match = re.search(r"microsoft-iis/([\d\.]+)", server_hdr, re.IGNORECASE)
            version = v_match.group(1) if v_match else None
            technologies.append(TechFingerprint("Microsoft IIS", "Servidor Web", version=version, evidence=f"Server: {server_hdr}"))
            technologies.append(TechFingerprint("Windows Server", "Sistema Operativo", evidence="Inferido por presencia de IIS"))
            if version:
                self._check_iis_cves(version, findings)

        elif "cloudflare" in server_hdr.lower() or "cf-ray" in self.headers:
            technologies.append(TechFingerprint("Cloudflare", "CDN / WAF / Proxy Inverso", evidence=f"Server: {server_hdr} / CF-RAY"))

        elif "litespeed" in server_hdr.lower():
            technologies.append(TechFingerprint("LiteSpeed", "Servidor Web", evidence=f"Server: {server_hdr}"))

        elif "caddy" in server_hdr.lower():
            technologies.append(TechFingerprint("Caddy", "Servidor Web Moderno", evidence=f"Server: {server_hdr}"))

        # --- 2. OPERATING SYSTEMS HINTS ---
        if "ubuntu" in server_hdr.lower() or "ubuntu" in powered_by.lower():
            technologies.append(TechFingerprint("Ubuntu Linux", "Sistema Operativo", confidence="ALTA", evidence=f"Cabecera: {server_hdr}"))
        elif "debian" in server_hdr.lower() or "debian" in powered_by.lower():
            technologies.append(TechFingerprint("Debian Linux", "Sistema Operativo", confidence="ALTA", evidence=f"Cabecera: {server_hdr}"))
        elif "centos" in server_hdr.lower() or "redhat" in server_hdr.lower() or "fedora" in server_hdr.lower():
            technologies.append(TechFingerprint("RHEL / CentOS Linux", "Sistema Operativo", confidence="ALTA", evidence=f"Cabecera: {server_hdr}"))
        elif "win32" in server_hdr.lower() or "win64" in server_hdr.lower() or "windows" in server_hdr.lower():
            technologies.append(TechFingerprint("Windows Server", "Sistema Operativo", confidence="ALTA", evidence=f"Cabecera: {server_hdr}"))

        # --- 3. RUNTIMES & BACKEND FRAMEWORKS ---
        if "php" in powered_by.lower() or any(c.lower().startswith("phpsessid") for c in self.cookies):
            v_match = re.search(r"php/([\d\.]+)", powered_by, re.IGNORECASE)
            version = v_match.group(1) if v_match else None
            technologies.append(TechFingerprint("PHP", "Lenguaje de Programación / Runtime", version=version, evidence=f"X-Powered-By: {powered_by}" if powered_by else "PHPSESSID Cookie"))
            if version:
                self._check_php_version(version, findings)

        if "asp.net" in powered_by.lower() or "x-aspnet-version" in self.headers or any("asp.net_sessionid" in c.lower() for c in self.cookies):
            technologies.append(TechFingerprint("ASP.NET", "Framework Web", evidence="Cabecera o Cookie ASP.NET"))

        if "express" in powered_by.lower():
            technologies.append(TechFingerprint("Express.js", "Framework Node.js", evidence=f"X-Powered-By: {powered_by}"))

        if "werkzeug" in server_hdr.lower():
            technologies.append(TechFingerprint("Werkzeug / Flask", "Framework Python", evidence=f"Server: {server_hdr}"))

        # --- 4. CMS DETECTION ---
        # WordPress
        is_wp = False
        wp_ver = None
        if "/wp-content/" in self.html_content or "/wp-includes/" in self.html_content:
            is_wp = True
        if self.soup:
            meta_gen = self.soup.find("meta", attrs={"name": re.compile(r"generator", re.I)})
            if meta_gen and meta_gen.get("content"):
                gen_content = meta_gen.get("content", "")
                if "wordpress" in gen_content.lower():
                    is_wp = True
                    v_match = re.search(r"wordpress\s*([\d\.]+)", gen_content, re.IGNORECASE)
                    if v_match:
                        wp_ver = v_match.group(1)

        if is_wp:
            technologies.append(TechFingerprint("WordPress", "CMS (Content Management System)", version=wp_ver, confidence="ALTA", evidence="Rutas /wp-content/ o Meta Generator"))
            if wp_ver:
                self._check_wordpress_cves(wp_ver, findings)

        # Drupal
        if "drupal" in self.html_content.lower() or "x-drupal-cache" in self.headers or "x-generator" in self.headers and "drupal" in self.headers["x-generator"].lower():
            technologies.append(TechFingerprint("Drupal", "CMS", evidence="Cabecera X-Drupal o Generator"))

        # Joomla
        if "joomla" in self.html_content.lower() or any("joomla" in c.lower() for c in self.cookies):
            technologies.append(TechFingerprint("Joomla", "CMS", evidence="Estructura HTML o Cookie Joomla"))

        # --- 5. FRONTEND FRAMEWORKS & LIBRARIES ---
        if self.html_content:
            if "react" in self.html_content or "_next" in self.html_content or "data-reactroot" in self.html_content:
                technologies.append(TechFingerprint("React / Next.js", "Framework Frontend", evidence="Atributos o scripts React / Next.js"))
            if "vue" in self.html_content or "data-v-" in self.html_content or "_nuxt" in self.html_content:
                technologies.append(TechFingerprint("Vue.js / Nuxt", "Framework Frontend", evidence="Directivas Vue o bundles Nuxt"))
            if "jquery" in self.html_content.lower():
                v_match = re.search(r"jquery[-/.]([\d\.]+)", self.html_content, re.IGNORECASE)
                ver = v_match.group(1) if v_match else None
                technologies.append(TechFingerprint("jQuery", "Biblioteca JavaScript", version=ver, evidence="Firma en scripts HTML"))
            if "bootstrap" in self.html_content.lower():
                technologies.append(TechFingerprint("Bootstrap", "Framework UI CSS", evidence="Clases CSS de Bootstrap"))
            if "tailwind" in self.html_content.lower():
                technologies.append(TechFingerprint("Tailwind CSS", "Framework CSS", evidence="Estructuras de utilidades Tailwind"))

        return technologies, findings

    def _check_apache_cves(self, version: str, findings: List[Finding]):
        parts = [int(p) for p in re.findall(r"\d+", version)]
        if len(parts) >= 3 and parts[0] == 2 and parts[1] == 4:
            patch = parts[2]
            # Known major CVEs for Apache 2.4
            if patch in [49, 50]:
                kb = VULNERABILITIES_KB[37]
                findings.append(Finding(
                    id="CVE-2021-41773",
                    vuln_number=37,
                    title="Apache HTTP Server Crítico: Path Traversal / RCE (CVE-2021-41773 / CVE-2021-42013)",
                    category=kb["chapter"],
                    severity=Severity.CRITICAL,
                    status=FindingStatus.CONFIRMED,
                    affected_component=f"Apache httpd versión {version}",
                    technical_description=f"La versión detectada ({version}) contiene una falla crítica en la normalización de rutas de mod_rewrite/core que permite navegación arbitraria fuera del DocumentRoot e incluso ejecución remota de comandos si mod_cgi está activo.",
                    evidence=f"Versión de Apache expuesta: {version}",
                    impact=kb["impact"],
                    remediation="Actualizar inmediatamente a Apache HTTP Server 2.4.51 o superior."
                ))
            elif patch < 40:
                kb = VULNERABILITIES_KB[37]
                findings.append(Finding(
                    id="VULN-APACHE-OUTDATED",
                    vuln_number=37,
                    title="Versión Heredada y Desactualizada de Apache HTTP Server",
                    category=kb["chapter"],
                    severity=Severity.MEDIUM,
                    status=FindingStatus.POTENTIAL,
                    affected_component=f"Apache httpd versión {version}",
                    technical_description=f"La versión {version} carece de múltiples parches acumulados de seguridad para denegación de servicio HTTP/2, memory leaks y desincronización de peticiones.",
                    evidence=f"Banner Server: Apache/{version}",
                    impact=kb["impact"],
                    remediation="Actualizar a la última versión disponible en el canal estable del sistema operativo."
                ))

    def _check_nginx_cves(self, version: str, findings: List[Finding]):
        parts = [int(p) for p in re.findall(r"\d+", version)]
        if len(parts) >= 2:
            major, minor = parts[0], parts[1]
            if major < 1 or (major == 1 and minor < 18):
                kb = VULNERABILITIES_KB[38]
                findings.append(Finding(
                    id="VULN-NGINX-OUTDATED",
                    vuln_number=38,
                    title="Versión Obsoleta de Nginx Detectada",
                    category=kb["chapter"],
                    severity=Severity.MEDIUM,
                    status=FindingStatus.POTENTIAL,
                    affected_component=f"Nginx versión {version}",
                    technical_description=f"La versión de Nginx detectada ({version}) tiene fin de soporte (EOL) y es susceptible a fallos en el módulo HTTP/2 y parsing de cabeceras.",
                    evidence=f"Server: nginx/{version}",
                    impact=kb["impact"],
                    remediation="Actualizar al paquete estable actual de Nginx (1.24+ o 1.26+)."
                ))

    def _check_iis_cves(self, version: str, findings: List[Finding]):
        parts = [int(p) for p in re.findall(r"\d+", version)]
        if len(parts) >= 1 and parts[0] < 8:
            kb = VULNERABILITIES_KB[39]
            findings.append(Finding(
                id="VULN-IIS-LEGACY",
                vuln_number=39,
                title="Versión Heredada de Microsoft IIS (Sin Soporte)",
                category=kb["chapter"],
                severity=Severity.HIGH,
                status=FindingStatus.CONFIRMED,
                affected_component=f"Microsoft IIS {version}",
                technical_description=f"Las versiones de IIS inferiores a 8.5 (como IIS {version}) corresponden a sistemas Windows Server descontinuados (2008/2003) y poseen fallos críticos acumulados.",
                evidence=f"Server: Microsoft-IIS/{version}",
                impact=kb["impact"],
                remediation="Migrar a una versión moderna de Windows Server con soporte de seguridad extendido."
            ))

    def _check_php_version(self, version: str, findings: List[Finding]):
        parts = [int(p) for p in re.findall(r"\d+", version)]
        if len(parts) >= 2:
            major, minor = parts[0], parts[1]
            if major < 8 or (major == 8 and minor < 1):
                findings.append(Finding(
                    id="VULN-PHP-EOL",
                    vuln_number=40,
                    title="Versión de PHP con Fin de Vida Útil (EOL) Detectada",
                    category="Servidores y Componentes",
                    severity=Severity.HIGH,
                    status=FindingStatus.CONFIRMED,
                    affected_component=f"Intérprete PHP versión {version}",
                    technical_description=f"La rama PHP {major}.{minor} ya no recibe actualizaciones de seguridad por parte del equipo oficial de PHP (End of Life).",
                    evidence=f"X-Powered-By: PHP/{version}",
                    impact="Presencia de vulnerabilidades sin posibilidad de parcheo directo sin actualizar el entorno.",
                    remediation="Migrar el código fuente para ejecutar sobre PHP 8.2 o PHP 8.3 con soporte activo."
                ))

    def _check_wordpress_cves(self, version: str, findings: List[Finding]):
        parts = [int(p) for p in re.findall(r"\d+", version)]
        if len(parts) >= 2:
            major, minor = parts[0], parts[1]
            if major < 6 or (major == 6 and minor < 4):
                kb = VULNERABILITIES_KB[66]
                findings.append(Finding(
                    id="VULN-WP-OUTDATED",
                    vuln_number=66,
                    title="Núcleo de WordPress Desactualizado",
                    category=kb["chapter"],
                    severity=Severity.HIGH,
                    status=FindingStatus.POTENTIAL,
                    affected_component=f"WordPress Core {version}",
                    technical_description=f"La versión expuesta de WordPress ({version}) tiene fallos de seguridad conocidos corregidos en versiones posteriores.",
                    evidence=f"Meta Generator WordPress: {version}",
                    impact=kb["impact"],
                    remediation="Actualizar el núcleo de WordPress a la versión más reciente desde el panel de administración o mediante wp-cli."
                ))
