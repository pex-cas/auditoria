"""
DNS Infrastructure Security Analyzer.
Audits SPF/DMARC records (SEC-092), Zone Transfers (SEC-087), and Subdomain Takeover pointers (SEC-088).
"""
from typing import List, Dict, Any, Tuple
import dns.resolver
import dns.query
import dns.zone
from engine.models import Finding, Severity, FindingStatus
from engine.knowledge_base import VULNERABILITIES_KB

class DNSAnalyzer:
    def __init__(self, domain: str, timeout: int = 4):
        self.domain = domain.split(':')[0]
        self.timeout = timeout
        self.resolver = dns.resolver.Resolver()
        self.resolver.lifetime = timeout

    def analyze(self) -> Tuple[Dict[str, Any], List[Finding]]:
        dns_info = {
            "a": [],
            "mx": [],
            "txt": [],
            "cname": [],
            "ns": [],
            "spf": None,
            "dmarc": None
        }
        findings: List[Finding] = []

        # 1. Resolve A / AAAA
        try:
            answers = self.resolver.resolve(self.domain, 'A')
            dns_info["a"] = [str(r) for r in answers]
        except Exception:
            pass

        # 2. Resolve NS
        try:
            answers = self.resolver.resolve(self.domain, 'NS')
            dns_info["ns"] = [str(r).rstrip('.') for r in answers]
        except Exception:
            pass

        # 3. Resolve MX
        try:
            answers = self.resolver.resolve(self.domain, 'MX')
            dns_info["mx"] = [str(r.exchange).rstrip('.') for r in answers]
        except Exception:
            pass

        # 4. Resolve TXT & Check SPF (SEC-092)
        try:
            answers = self.resolver.resolve(self.domain, 'TXT')
            for r in answers:
                txt_str = "".join([part.decode('utf-8', errors='ignore') if isinstance(part, bytes) else str(part) for part in r.strings])
                dns_info["txt"].append(txt_str)
                if txt_str.startswith("v=spf1"):
                    dns_info["spf"] = txt_str
        except Exception:
            pass

        # 5. Check DMARC (SEC-092)
        try:
            dmarc_domain = f"_dmarc.{self.domain}"
            answers = self.resolver.resolve(dmarc_domain, 'TXT')
            for r in answers:
                txt_str = "".join([part.decode('utf-8', errors='ignore') if isinstance(part, bytes) else str(part) for part in r.strings])
                if txt_str.startswith("v=DMARC1"):
                    dns_info["dmarc"] = txt_str
        except Exception:
            pass

        # Evaluate Email Security (SPF & DMARC - SEC-092)
        self._evaluate_spf_dmarc(dns_info, findings)

        # 6. Check DNS Zone Transfer (AXFR - SEC-087)
        self._check_zone_transfer(dns_info.get("ns", []), findings)

        return dns_info, findings

    def _evaluate_spf_dmarc(self, dns_info: Dict[str, Any], findings: List[Finding]):
        kb = VULNERABILITIES_KB[92]

        # Check SPF
        spf = dns_info.get("spf")
        if not spf:
            findings.append(Finding(
                id="DNS-NO-SPF",
                vuln_number=92,
                title="Ausencia de Registro SPF (Riesgo de Suplantación de Correo)",
                category=kb["chapter"],
                severity=Severity.MEDIUM,
                status=FindingStatus.CONFIRMED,
                affected_component=f"DNS TXT ({self.domain})",
                technical_description="El dominio no cuenta con un registro SPF (Sender Policy Framework) publicado. Cualquier servidor de correo de terceros puede emitir correos fraudulentos suplantando el dominio corporativo.",
                evidence="Registro v=spf1 ausente en DNS TXT",
                impact=kb["impact"],
                remediation="Publicar un registro TXT con SPF estricto: 'v=spf1 mx -all' o incluyendo las IPs autorizadas."
            ))
        elif "+all" in spf or "?all" in spf:
            findings.append(Finding(
                id="DNS-SPF-PERMISSIVE",
                vuln_number=92,
                title="Registro SPF Excesivamente Permisivo (+all o ?all)",
                category=kb["chapter"],
                severity=Severity.LOW,
                status=FindingStatus.CONFIRMED,
                affected_component=f"DNS SPF ({self.domain})",
                technical_description=f"El registro SPF termina en directivas permisivas (+all o ?all) que no ordenan el rechazo de correos no autorizados.",
                evidence=f"SPF: {spf}",
                impact=kb["impact"],
                remediation="Modificar la directiva de cierre a '-all' (Hard Fail) o '~all' (Soft Fail)."
            ))

        # Check DMARC
        dmarc = dns_info.get("dmarc")
        if not dmarc:
            findings.append(Finding(
                id="DNS-NO-DMARC",
                vuln_number=92,
                title="Ausencia de Política DMARC en el Dominio",
                category=kb["chapter"],
                severity=Severity.MEDIUM,
                status=FindingStatus.CONFIRMED,
                affected_component=f"DNS TXT (_dmarc.{self.domain})",
                technical_description="No se encontró registro DMARC. Los servidores receptores de correo no tienen directrices para rechazar o poner en cuarentena correos falsificados que fallen SPF o DKIM.",
                evidence="Registro _dmarc ausente",
                impact=kb["impact"],
                remediation="Publicar registro TXT en _dmarc: 'v=DMARC1; p=reject; rua=mailto:dmarc-reports@midominio.com;'"
            ))
        elif "p=none" in dmarc:
            findings.append(Finding(
                id="DNS-DMARC-POLICY-NONE",
                vuln_number=92,
                title="Política DMARC en Modo Solo Monitoreo (p=none)",
                category=kb["chapter"],
                severity=Severity.LOW,
                status=FindingStatus.CONFIRMED,
                affected_component=f"DNS DMARC ({self.domain})",
                technical_description="DMARC está configurado con política 'p=none', lo que significa que los correos que no superen la autenticación serán entregados igualmente a los destinatarios sin bloqueo.",
                evidence=f"DMARC: {dmarc}",
                impact="Falta de mitigación activa contra phishing del dominio.",
                remediation="Progresar la política DMARC a 'p=quarantine' o 'p=reject'."
            ))

    def _check_zone_transfer(self, nameservers: List[str], findings: List[Finding]):
        """Attempts an AXFR query against authoritative nameservers."""
        for ns in nameservers[:2]: # Test up to 2 NS to avoid excessive network load
            try:
                # Query zone transfer with short timeout
                zone = dns.zone.from_xfr(dns.query.xfr(ns, self.domain, timeout=self.timeout))
                if zone and len(zone.nodes) > 1:
                    kb = VULNERABILITIES_KB[87]
                    findings.append(Finding(
                        id=f"DNS-AXFR-OPEN-{ns}",
                        vuln_number=87,
                        title=f"Transferencia de Zona DNS Abierta (AXFR) en {ns}",
                        category=kb["chapter"],
                        severity=Severity.HIGH,
                        status=FindingStatus.CONFIRMED,
                        affected_component=f"Servidor DNS {ns}",
                        technical_description=f"El servidor de nombres autoritativo {ns} permite transferencias completas de zona (AXFR) a clientes anónimos de Internet. Expone la totalidad de registros, subdominios e infraestructura de red interna.",
                        evidence=f"Transferencia AXFR exitosa: {len(zone.nodes)} nodos obtenidos desde {ns}",
                        impact=kb["impact"],
                        remediation=kb["remediation"]
                    ))
                    break
            except Exception:
                pass
