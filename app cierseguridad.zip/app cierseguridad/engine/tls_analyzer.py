"""
TLS/SSL and Cryptographic Security Analyzer.
Evaluates certificates, expiration, host matching, supported TLS protocol versions, and cipher suites.
"""
import socket
import ssl
import datetime
from typing import List, Dict, Any, Tuple
from engine.models import Finding, Severity, FindingStatus
from engine.knowledge_base import VULNERABILITIES_KB

class TLSAnalyzer:
    def __init__(self, host: str, port: int = 443, timeout: int = 5):
        self.host = host
        self.port = port
        self.timeout = timeout

    def analyze(self) -> Tuple[Dict[str, Any], List[Finding]]:
        tls_info = {
            "enabled": False,
            "version": None,
            "cipher": None,
            "certificate": None,
            "expires_in_days": None,
            "issuer": None,
            "subject": None,
            "san": [],
            "issues": []
        }
        findings: List[Finding] = []

        # 1. Establish SSL connection and inspect live certificate
        context = ssl.create_default_context()
        context.check_hostname = True
        context.verify_mode = ssl.CERT_REQUIRED

        try:
            with socket.create_connection((self.host, self.port), timeout=self.timeout) as sock:
                with context.wrap_socket(sock, server_hostname=self.host) as ssock:
                    cert = ssock.getpeercert()
                    tls_version = ssock.version()
                    cipher_tuple = ssock.cipher()
                    
                    tls_info["enabled"] = True
                    tls_info["version"] = tls_version
                    tls_info["cipher"] = cipher_tuple[0] if cipher_tuple else "Unknown"

                    # Parse certificate details
                    if cert:
                        not_after_str = cert.get('notAfter')
                        if not_after_str:
                            expiry = datetime.datetime.strptime(not_after_str, '%b %d %H:%M:%S %Y %Z')
                            now = datetime.datetime.utcnow()
                            days_left = (expiry - now).days
                            tls_info["expires_in_days"] = days_left
                            tls_info["not_after"] = str(expiry)

                            if days_left < 0:
                                kb = VULNERABILITIES_KB[32]
                                findings.append(Finding(
                                    id="TLS-EXP-01",
                                    vuln_number=32,
                                    title="Certificado SSL/TLS Caducado",
                                    category=kb["chapter"],
                                    severity=Severity.HIGH,
                                    status=FindingStatus.CONFIRMED,
                                    affected_component="Certificado X.509",
                                    technical_description=f"El certificado SSL presentado por el servidor expiró hace {-days_left} días.",
                                    evidence=f"Vigencia hasta: {not_after_str} (Días restantes: {days_left})",
                                    impact=kb["impact"],
                                    remediation=kb["remediation"]
                                ))
                            elif days_left < 15:
                                kb = VULNERABILITIES_KB[32]
                                findings.append(Finding(
                                    id="TLS-EXP-WARN",
                                    vuln_number=32,
                                    title="Certificado SSL/TLS Próximo a Caducar",
                                    category=kb["chapter"],
                                    severity=Severity.LOW,
                                    status=FindingStatus.CONFIRMED,
                                    affected_component="Certificado X.509",
                                    technical_description=f"El certificado expira en {days_left} días. Si no se renueva, provocará advertencias graves de seguridad a los visitantes.",
                                    evidence=f"Vencimiento: {not_after_str}",
                                    impact=kb["impact"],
                                    remediation=kb["remediation"]
                                ))

                        # Extract Issuer and Subject
                        subject_dict = dict(x[0] for x in cert.get('subject', ()))
                        issuer_dict = dict(x[0] for x in cert.get('issuer', ()))
                        tls_info["subject"] = subject_dict.get('commonName', self.host)
                        tls_info["issuer"] = issuer_dict.get('organizationName', issuer_dict.get('commonName', 'Unknown CA'))

                        # Subject Alternative Names (SAN)
                        san_list = [entry[1] for entry in cert.get('subjectAltName', ()) if entry[0] == 'DNS']
                        tls_info["san"] = san_list

        except ssl.SSLCertVerificationError as e:
            tls_info["enabled"] = True
            tls_info["issues"].append(f"Error de verificación: {e.verify_message}")
            kb = VULNERABILITIES_KB[32]
            findings.append(Finding(
                id="TLS-VERIFY-ERR",
                vuln_number=32,
                title="Fallo en la Validación del Certificado SSL/TLS",
                category=kb["chapter"],
                severity=Severity.HIGH,
                status=FindingStatus.CONFIRMED,
                affected_component="Cadena de confianza SSL/TLS",
                technical_description=f"El certificado digital no supera la validación de confianza: {e.verify_message}. Posible certificado autofirmado o cadena incompleta.",
                evidence=str(e),
                impact=kb["impact"],
                remediation=kb["remediation"]
            ))
        except (socket.timeout, socket.gaierror, ConnectionRefusedError, OSError):
            tls_info["enabled"] = False
            return tls_info, findings

        # 2. Check for Legacy/Obsolete Protocol versions (TLS 1.0 / 1.1)
        findings.extend(self._check_legacy_protocols())

        # 3. Check for Weak Ciphers
        if tls_info["cipher"]:
            cipher_name = tls_info["cipher"].upper()
            if any(weak in cipher_name for weak in ["RC4", "3DES", "DES", "MD5", "NULL", "EXPORT", "CBC"]):
                kb = VULNERABILITIES_KB[31]
                findings.append(Finding(
                    id="TLS-WEAK-CIPHER",
                    vuln_number=31,
                    title="Suite de Cifrado TLS Débil o Heredada Negociada",
                    category=kb["chapter"],
                    severity=Severity.MEDIUM,
                    status=FindingStatus.CONFIRMED,
                    affected_component=f"Suite de Cifrado: {tls_info['cipher']}",
                    technical_description=f"El servidor negoció la suite '{tls_info['cipher']}', la cual contiene algoritmos obsoletos o susceptibles a debilidades criptográficas.",
                    evidence=f"Cifrado activo: {tls_info['cipher']}",
                    impact=kb["impact"],
                    remediation=kb["remediation"]
                ))

        return tls_info, findings

    def _check_legacy_protocols(self) -> List[Finding]:
        findings = []
        # Attempt handshake with TLS 1.0 or 1.1 explicitly if supported by the OS OpenSSL build
        for proto_name, proto_const in [("TLSv1", getattr(ssl, "PROTOCOL_TLSv1", None)),
                                         ("TLSv1.1", getattr(ssl, "PROTOCOL_TLSv1_1", None))]:
            if proto_const is None:
                continue
            try:
                legacy_ctx = ssl.SSLContext(proto_const)
                legacy_ctx.check_hostname = False
                legacy_ctx.verify_mode = ssl.CERT_NONE
                with socket.create_connection((self.host, self.port), timeout=self.timeout) as sock:
                    with legacy_ctx.wrap_socket(sock) as ssock:
                        kb = VULNERABILITIES_KB[29]
                        findings.append(Finding(
                            id=f"TLS-LEGACY-{proto_name}",
                            vuln_number=29,
                            title=f"Soporte Inseguro de Protocolo Obsoleto ({proto_name})",
                            category=kb["chapter"],
                            severity=Severity.HIGH,
                            status=FindingStatus.CONFIRMED,
                            affected_component=f"Configuración SSL/TLS ({proto_name})",
                            technical_description=f"El servidor web acepta conexiones utilizando {proto_name}. Este protocolo está oficialmente deprecado por el IETF (RFC 8996) debido a debilidades estructurales conocidas (BEAST, POODLE).",
                            evidence=f"Apretón de manos exitoso con protocolo {proto_name}",
                            impact=kb["impact"],
                            remediation="Deshabilitar SSLv2, SSLv3, TLS 1.0 y TLS 1.1 en la configuración del servidor web (ej. ssl_protocols TLSv1.2 TLSv1.3; en Nginx)."
                        ))
                        break # One legacy finding is sufficient
            except Exception:
                # Normal behavior: secure server will reject legacy handshake
                pass
        return findings
