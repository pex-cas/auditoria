"""
Thread-safe event streaming logger for the audit engine.
Allows pushing real-time log lines and events directly to the frontend via Server-Sent Events (SSE).
"""
import time
import queue
from typing import Optional, Dict, Any

class AuditLogger:
    def __init__(self):
        self.history: list[str] = []
        self.listeners: list[queue.Queue] = []

    def subscribe(self) -> queue.Queue:
        q = queue.Queue(maxsize=1000)
        self.listeners.append(q)
        return q

    def unsubscribe(self, q: queue.Queue):
        if q in self.listeners:
            self.listeners.remove(q)

    def log(self, message: str, level: str = "INFO", meta: Optional[Dict[str, Any]] = None):
        timestamp = time.strftime("%H:%M:%S")
        entry = f"[{timestamp}] [{level}] {message}"
        self.history.append(entry)

        event_data = {
            "timestamp": timestamp,
            "level": level,
            "message": message,
            "meta": meta or {}
        }

        # Broadcast to all active SSE listener queues
        for q in list(self.listeners):
            try:
                q.put_nowait(event_data)
            except queue.Full:
                pass
