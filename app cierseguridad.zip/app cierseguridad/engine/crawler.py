"""
Crawler con control de alcance.

Antes el motor solo miraba la página principal ("/"), por eso nunca encontraba vulnerabilidades dentro de
la aplicación. Este módulo recorre el sitio (BFS), respeta el alcance del SafeRequester y devuelve los
"puntos de inyección" encontrados: URLs con parámetros y formularios.

Seguridad: no sigue enlaces de cierre de sesión ni de borrado, para no destruir la sesión ni datos.
"""
import re
import urllib.parse
from collections import deque
from typing import Dict, List, Any, Optional

from bs4 import BeautifulSoup

from engine.scope import SafeRequester, ScopeViolationError

SKIP_URL_RE = re.compile(r"(logout|log-out|signout|sign-out|logoff|delete|remove|destroy|unsubscribe|reset|setup\.php)", re.I)
STATIC_EXT_RE = re.compile(r"\.(png|jpe?g|gif|svg|ico|css|js|map|woff2?|ttf|eot|pdf|zip|gz|mp4|mp3|webp)(\?|$)", re.I)


class InjectionPoint(dict):
    """method, url (sin query), params (dict con valores base), source (página donde se vio)."""


class Crawler:
    def __init__(self, requester: SafeRequester, start_url: str, max_pages: int = 40, max_depth: int = 2,
                 seed_urls: Optional[List[str]] = None, logger=None):
        self.req = requester
        self.start_url = start_url
        self.max_pages = max_pages
        self.max_depth = max_depth
        self.seed_urls = seed_urls or []
        self.log = logger
        self.visited: List[str] = []
        self.points: List[InjectionPoint] = []
        self.spa_suspected = False
        self._seen_points = set()

    # ------------------------------------------------------------------
    def _say(self, msg: str, level: str = "INFO"):
        if self.log:
            self.log.log(msg, level)

    @staticmethod
    def _clean(url: str) -> str:
        url, _ = urllib.parse.urldefrag(url)
        return url

    def _add_point(self, method: str, url: str, params: Dict[str, str], source: str):
        base = url.split("?")[0]
        key = (method, base, tuple(sorted(params.keys())))
        if not params or key in self._seen_points:
            return
        self._seen_points.add(key)
        self.points.append(InjectionPoint(method=method, url=base, params=params, source=source))

    # ------------------------------------------------------------------
    def crawl(self) -> Dict[str, Any]:
        queue = deque()
        queued = set()

        def enqueue(u: str, depth: int):
            u = self._clean(u)
            if u in queued or not self.req.is_in_scope(u) or STATIC_EXT_RE.search(u) or SKIP_URL_RE.search(u):
                return
            queued.add(u)
            queue.append((u, depth))

        enqueue(self.start_url, 0)
        for s in self.seed_urls:
            enqueue(urllib.parse.urljoin(self.start_url, s.strip()), 0)
        # Descubrimiento barato: sitemap.xml
        try:
            sm = self.req.get("/sitemap.xml", allow_redirects=True)
            if sm.status_code == 200 and "<loc>" in sm.text:
                for loc in re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", sm.text)[:30]:
                    enqueue(loc, 1)
        except Exception:
            pass

        total_links = 0
        while queue and len(self.visited) < self.max_pages:
            url, depth = queue.popleft()
            try:
                resp = self.req.get(url, allow_redirects=True)
            except ScopeViolationError:
                continue
            except Exception as e:
                self._say(f"Crawler: no se pudo leer {url}: {e}", "WARN")
                continue

            self.visited.append(url)
            ctype = resp.headers.get("Content-Type", "").lower()

            # Los parámetros de la propia URL visitada también son puntos de prueba
            q = urllib.parse.urlparse(url).query
            if q:
                self._add_point("GET", url, dict(urllib.parse.parse_qsl(q, keep_blank_values=True)), url)

            # Endpoints JSON/API sembrados por el usuario: no hay HTML que parsear
            if "html" not in ctype:
                continue

            soup = BeautifulSoup(resp.text or "", "html.parser")
            links = 0
            for a in soup.find_all("a", href=True):
                href = a["href"].strip()
                if href.startswith(("mailto:", "tel:", "javascript:", "#")):
                    continue
                target = urllib.parse.urljoin(resp.url, href)
                links += 1
                if depth < self.max_depth:
                    enqueue(target, depth + 1)
                else:
                    # a profundidad máxima no se visita, pero sí se registran sus parámetros
                    p = urllib.parse.urlparse(target)
                    if p.query and self.req.is_in_scope(target) and not SKIP_URL_RE.search(target):
                        self._add_point("GET", target, dict(urllib.parse.parse_qsl(p.query, keep_blank_values=True)), url)
            total_links += links

            for form in soup.find_all("form"):
                action = urllib.parse.urljoin(resp.url, form.get("action") or resp.url)
                if not self.req.is_in_scope(action) or SKIP_URL_RE.search(action):
                    continue
                method = (form.get("method") or "GET").upper()
                params: Dict[str, str] = {}
                has_password = False
                for inp in form.find_all(["input", "textarea", "select"]):
                    name = inp.get("name")
                    itype = (inp.get("type") or "text").lower()
                    if not name or itype in ("file", "button", "reset", "image"):
                        continue
                    if itype == "password":
                        has_password = True
                    if inp.name == "select":
                        opt = inp.find("option")
                        params[name] = (opt.get("value", opt.text) if opt else "") or ""
                    elif itype in ("checkbox", "radio"):
                        params[name] = inp.get("value", "on")
                    else:
                        params[name] = inp.get("value", "") or ("test" if itype in ("text", "search", "email", "url") else "")
                if has_password:
                    continue  # nunca se prueban formularios de login/contraseña
                self._add_point(method, action, params, url)

            # Heurística de SPA: casi sin enlaces y con raíz de framework JS
            if depth == 0 and links < 3 and re.search(r'(<app-root|id="root"|id="app"|ng-version|__NEXT_DATA__|data-reactroot)', resp.text or ""):
                self.spa_suspected = True

        if self.spa_suspected:
            self._say("El sitio parece una SPA (Angular/React/Vue): un rastreador sin JavaScript casi no ve enlaces. "
                      "Agregá URLs de API o páginas concretas en 'URLs semilla' (ej. /rest/products/search?q=test).", "WARN")

        return {
            "pages_visited": len(self.visited),
            "injection_points": len(self.points),
            "spa_suspected": self.spa_suspected,
            "total_links_seen": total_links,
        }
