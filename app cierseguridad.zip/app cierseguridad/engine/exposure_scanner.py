"""
Safe Exposure Scanner:
Conducts non-destructive probes for critical sensitive files, directories, and endpoints.
Applies rigorous content validation and heuristics to eliminate Soft-404 false positives.
"""
import re
from typing import List, Dict, Any, Tuple
import requests
from engine.scope import SafeRequester
from engine.models import Finding, Severity, FindingStatus
from engine.knowledge_base import VULNERABILITIES_KB

class ExposureScanner:
    def __init__(self, requester: SafeRequester, base_url: str):
        self.requester = requester
        self.base_url = base_url
        self.soft_404_fingerprint = self._determine_soft_404()

    def _determine_soft_404(self) -> Dict[str, Any]:
        """Requests a non-existent random endpoint to profile custom 404 behavior."""
        random_path = "/non_existent_check_9948274a1b0c.html"
        try:
            resp = self.requester.get(random_path, allow_redirects=False)
            return {
                "status_code": resp.status_code,
                "length": len(resp.text),
                "is_html": "text/html" in resp.headers.get("Content-Type", "").lower()
            }
        except Exception:
            return {"status_code": 404, "length": 0, "is_html": False}

    def scan(self) -> List[Finding]:
        findings: List[Finding] = []

        targets = [
            # 1. Environment and configuration files (SEC-065)
            {
                "path": "/.env",
                "vuln_num": 65,
                "title": "Exposición Crítica de Archivo .env (Credenciales y Secretos)",
                "severity": Severity.CRITICAL,
                "validator": lambda r: r.status_code == 200 and ("DB_PASSWORD" in r.text or "APP_KEY" in r.text or "SECRET_KEY" in r.text or re.search(r"^[A-Z0-9_]+=[^\r\n]+", r.text, re.M)),
                "desc": "El archivo de entorno .env está expuesto públicamente. Contiene claves maestras, credenciales de base de datos y llaves de cifrado.",
                "remed": "Bloquear inmediatamente en el servidor web el acceso a todos los archivos que inicien con un punto (.) y revocar las credenciales expuestas."
            },
            {
                "path": "/.git/HEAD",
                "vuln_num": 65,
                "title": "Exposición de Repositorio de Control de Versiones (.git)",
                "severity": Severity.HIGH,
                "validator": lambda r: r.status_code == 200 and ("ref: refs/" in r.text or re.match(r"^[0-9a-f]{40}$", r.text.strip())),
                "desc": "El directorio .git del repositorio es accesible públicamente. Permite reconstruir todo el código fuente del proyecto y su historial de commits.",
                "remed": "Configurar el servidor web para denegar solicitudes a rutas que contengan /.git/ y excluir el directorio .git durante el despliegue."
            },
            # 2. Apache Server Status (SEC-044)
            {
                "path": "/server-status",
                "vuln_num": 44,
                "title": "Página de Estado del Servidor Expuesta (Apache server-status)",
                "severity": Severity.MEDIUM,
                "validator": lambda r: r.status_code == 200 and ("Apache Server Status" in r.text or "Server Version:" in r.text),
                "desc": "El módulo mod_status de Apache está expuesto sin autenticación, divulgando IPs de usuarios, peticiones HTTP activas y uso de memoria.",
                "remed": "Restringir el acceso a localhost mediante 'Require local' en la configuración de mod_status."
            },
            # 3. Debug Interfaces / Profilers (SEC-045)
            {
                "path": "/phpinfo.php",
                "vuln_num": 45,
                "title": "Exposición de Interfaz de Diagnóstico phpinfo()",
                "severity": Severity.HIGH,
                "validator": lambda r: r.status_code == 200 and "PHP Version" in r.text and "Configuration" in r.text and "<title>phpinfo()</title>" in r.text,
                "desc": "Se encontró un script phpinfo() accesible públicamente, revelando rutas del servidor, variables de entorno compiladas y extensiones activas.",
                "remed": "Eliminar de inmediato el archivo phpinfo.php del servidor web de producción."
            },
            {
                "path": "/_profiler/",
                "vuln_num": 45,
                "title": "Profiler de Framework Expuesto en Producción (Symfony / Debug Bar)",
                "severity": Severity.HIGH,
                "validator": lambda r: r.status_code == 200 and ("Symfony Web Profiler" in r.text or "profiler/empty" in r.text or "debug-bar" in r.text),
                "desc": "La barra de depuración de Symfony / PHP está activa en producción, exponiendo consultas SQL completas y parámetros de peticiones.",
                "remed": "Desactivar el entorno de desarrollo estableciendo APP_ENV=prod y deshabilitando el paquete de profiling."
            },
            # 4. Directory Listing (SEC-046)
            {
                "path": "/uploads/",
                "vuln_num": 46,
                "title": "Listado de Directorios Habilitado (Directory Listing Exposure)",
                "severity": Severity.MEDIUM,
                "validator": lambda r: r.status_code == 200 and ("Index of /uploads" in r.text or "<title>Index of" in r.text) and ("Parent Directory" in r.text or "<pre>" in r.text),
                "desc": "El servidor web genera un índice navegable de los archivos almacenados en la carpeta de subidas, permitiendo ver todos los ficheros existentes.",
                "remed": "Deshabilitar autoindexado: en Apache añadir 'Options -Indexes' y en Nginx 'autoindex off;'."
            },
            # 5. Sensitive Backups (SEC-064)
            {
                "path": "/backup.zip",
                "vuln_num": 64,
                "title": "Archivo de Respaldo Público Comprimido (/backup.zip)",
                "severity": Severity.CRITICAL,
                "validator": lambda r: r.status_code == 200 and (r.headers.get("Content-Type", "").startswith("application/zip") or r.content.startswith(b"PK\x03\x04")),
                "desc": "Se encontró un archivo comprimido de respaldo accesible para descarga. Podría contener el código fuente íntegro de la aplicación.",
                "remed": "Mover las copias de seguridad a un almacenamiento seguro fuera de la raíz web y protegerlas con cifrado."
            },
            # 6. Exposed Administrative Interfaces (SEC-048)
            {
                "path": "/admin/",
                "vuln_num": 48,
                "title": "Panel de Administración Expuesto en Ruta Predeterminada (/admin/)",
                "severity": Severity.LOW,
                "validator": lambda r: r.status_code in [200, 401, 403] and not self._is_soft_404(r),
                "desc": "Interfaz de administración detectable en la ruta estándar sin restricción de acceso a nivel de red.",
                "remed": "Cambiar la ruta predeterminada del panel de gestión, proteger con VPN / lista blanca de IPs y requerir autenticación MFA."
            },
            # 7. GraphQL Introspection Endpoint (SEC-084)
            {
                "path": "/graphql",
                "vuln_num": 84,
                "title": "Endpoint GraphQL Descubierto (/graphql)",
                "severity": Severity.INFO,
                "validator": lambda r: r.status_code in [200, 400] and ("must provide query string" in r.text.lower() or "graphql" in r.text.lower() or "json" in r.headers.get("Content-Type", "")),
                "desc": "Se identificó un endpoint de API GraphQL activo.",
                "remed": "Verificar que la introspección esté deshabilitada en producción y que cada resolver aplique autorización estricta."
            },
            # 8. Reconnaissance Helpers (robots.txt / security.txt)
            {
                "path": "/robots.txt",
                "vuln_num": 43,
                "title": "Análisis de Archivo robots.txt (Rutas Disallow Divulgadas)",
                "severity": Severity.INFO,
                "validator": lambda r: r.status_code == 200 and ("User-agent:" in r.text or "Disallow:" in r.text),
                "desc": "El archivo robots.txt contiene directivas para buscadores que pueden revelar rutas internas o paneles privados previstos para no ser indexados.",
                "remed": "Revisar las rutas listadas en Disallow para asegurar que no revelen directorios con información crítica o sensible."
            },
            {
                "path": "/.well-known/security.txt",
                "vuln_num": 43,
                "title": "Política de Divulgación de Vulnerabilidades (security.txt)",
                "severity": Severity.INFO,
                "validator": lambda r: r.status_code == 200 and "Contact:" in r.text,
                "desc": "El sitio implementa el estándar RFC 9116 para la recepción de reportes de seguridad coordinados.",
                "remed": "Mantener al día la fecha de vencimiento (Expires:) y canales de contacto en security.txt."
            }
        ]

        for item in targets:
            try:
                resp = self.requester.get(item["path"], allow_redirects=False)
                if self._is_soft_404(resp):
                    continue

                if item["validator"](resp):
                    kb = VULNERABILITIES_KB.get(item["vuln_num"], {})
                    # For robots.txt, extract disallow paths for evidence
                    evidence_text = f"URL: {resp.url} (HTTP {resp.status_code})"
                    if item["path"] == "/robots.txt":
                        disallows = [line.strip() for line in resp.text.splitlines() if line.strip().lower().startswith("disallow:")]
                        if disallows:
                            evidence_text += f"\nDisallow detectados: {', '.join(disallows[:5])}"

                    findings.append(Finding(
                        id=f"EXP-{item['vuln_num']}-{abs(hash(item['path'])) % 10000}",
                        vuln_number=item["vuln_num"],
                        title=item["title"],
                        category=kb.get("chapter", "Servidores y Componentes"),
                        severity=item["severity"],
                        status=FindingStatus.CONFIRMED if item["severity"] in [Severity.CRITICAL, Severity.HIGH] else FindingStatus.POTENTIAL,
                        affected_component=f"Ruta: {item['path']}",
                        technical_description=item["desc"],
                        evidence=evidence_text,
                        impact=kb.get("impact", "Divulgación o riesgo de compromiso."),
                        remediation=item["remed"]
                    ))
            except Exception:
                continue

        # Check GraphQL Introspection specifically if /graphql exists (SEC-084)
        self._check_graphql_introspection(findings)

        return findings

    def _is_soft_404(self, resp: requests.Response) -> bool:
        """Determines if a response is a disguised 404 (soft-404) page."""
        if resp.status_code == 404:
            return True
        # If the server returned 200 for our random non-existent page and length is nearly identical
        if self.soft_404_fingerprint["status_code"] == 200 and abs(len(resp.text) - self.soft_404_fingerprint["length"]) < 50:
            return True
        # Common 404 text in body despite 200 OK
        lower_body = resp.text[:1000].lower()
        if any(term in lower_body for term in ["page not found", "página no encontrada", "error 404", "404 not found"]):
            return True
        return False

    def _check_graphql_introspection(self, findings: List[Finding]):
        """Safely queries GraphQL introspection schema without burdening backend."""
        query = {"query": "{ __schema { types { name } } }"}
        try:
            resp = self.requester.post("/graphql", json=query, allow_redirects=False)
            if resp.status_code == 200 and "__schema" in resp.text and "types" in resp.text:
                kb = VULNERABILITIES_KB[84]
                findings.append(Finding(
                    id="EXP-GRAPHQL-INTROSPECTION",
                    vuln_number=84,
                    title="Introspección GraphQL Habilitada en Producción",
                    category=kb["chapter"],
                    severity=Severity.MEDIUM,
                    status=FindingStatus.CONFIRMED,
                    affected_component="Endpoint /graphql",
                    technical_description="El endpoint GraphQL responde a la consulta __schema con el catálogo completo de tipos y operaciones disponibles en la API.",
                    evidence=f"Respuesta HTTP 200 con __schema JSON (Tamaño: {len(resp.text)} bytes)",
                    impact=kb["impact"],
                    remediation=kb["remediation"]
                ))
        except Exception:
            pass
