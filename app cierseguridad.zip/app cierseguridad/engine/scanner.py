"""
Core Audit Engine Orchestrator.
Manages the scanning lifecycle, progress events, rate limiting, and produces the consolidated AuditReport.
"""
import time
import uuid
import urllib.parse
from typing import Optional, Dict, Any, List
import requests

from engine.models import ScanConfig, AuditReport, Finding, TechFingerprint, Severity, FindingStatus
from engine.scope import SafeRequester, ScopeViolationError
from engine.logger import AuditLogger
from engine.fingerprint import TechnologyFingerprinter
from engine.headers_analyzer import HeadersAnalyzer
from engine.tls_analyzer import TLSAnalyzer
from engine.dns_analyzer import DNSAnalyzer
from engine.exposure_scanner import ExposureScanner
from engine.web_checks import WebAppAnalyzer
from engine.crawler import Crawler
from engine.injection_checks import InjectionChecker
from engine.knowledge_base import VULNERABILITIES_KB

class SecurityAuditScanner:
    def __init__(self, config: ScanConfig, logger: Optional[AuditLogger] = None):
        self.config = config
        self.logger = logger or AuditLogger()
        self.scan_id = f"SCAN-{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6].upper()}"
        self.findings: List[Finding] = []
        self.technologies: List[TechFingerprint] = []
        self._tested_params = 0

    def run(self) -> AuditReport:
        start_time_iso = time.strftime("%Y-%m-%dT%H:%M:%S")
        start_timestamp = time.time()
        self.logger.history.clear()  # FIX: los logs de escaneos anteriores se mezclaban en cada reporte
        crawl_info = {}
        
        self.logger.log(f"Iniciando auditoría técnica de seguridad sobre {self.config.target_url}", "INFO", {"progress": 5})
        
        # 1. Scope & Domain Validation
        target_url = self.config.target_url.strip()
        if not target_url.startswith(("http://", "https://")):
            target_url = "https://" + target_url
            self.config.target_url = target_url

        parsed = urllib.parse.urlsplit(target_url)
        domain = parsed.hostname or parsed.netloc
        
        self.logger.log(f"Objetivo validado: {domain} | Modo: {self.config.scan_mode} | Límite: {self.config.max_requests_per_sec} req/s", "INFO", {"progress": 10})

        requester = SafeRequester(
            base_url=target_url,
            rate_limit=self.config.max_requests_per_sec,
            timeout=self.config.timeout_sec,
            max_duration_sec=self.config.max_duration_sec,
            cookies=self.config.cookies,
            extra_headers=self.config.extra_headers
        )

        # 1b. Autenticación (sin esto, las páginas internas de DVWA, bWAPP, etc. quedan invisibles)
        authenticated = bool(self.config.cookies or self.config.extra_headers)
        if self.config.login_url and self.config.login_username:
            try:
                ok, msg = requester.login(self.config.login_url, self.config.login_username, self.config.login_password,
                                          self.config.login_user_field, self.config.login_pass_field)
                self.logger.log(f"Login como '{self.config.login_username}': {msg}", "SUCCESS" if ok else "WARN")
                authenticated = authenticated or ok
            except Exception as e:
                self.logger.log(f"Falló el login automático: {e}", "WARN")

        initial_resp = None
        server_info = {}
        tls_info = {}

        # 2. Base HTTP Request & Profiling
        try:
            self.logger.log("Conectando con el objetivo y evaluando respuesta base HTTP...", "PHASE", {"progress": 15})
            initial_resp = requester.get("/", allow_redirects=True)
            server_info = {
                "final_url": initial_resp.url,
                "status_code": initial_resp.status_code,
                "headers": dict(initial_resp.headers),
                "encoding": initial_resp.encoding or "utf-8",
                "content_length": len(initial_resp.content)
            }
            self.logger.log(f"Respuesta HTTP recibida: Código {initial_resp.status_code} ({len(initial_resp.content)} bytes)", "SUCCESS", {"progress": 25})
        except ScopeViolationError as sve:
            self.logger.log(f"Violación de alcance detectada: {sve}", "ERROR", {"progress": 100})
            raise
        except Exception as e:
            self.logger.log(f"Error al conectar con el servidor web: {str(e)}", "ERROR", {"progress": 100})
            # Continue to test DNS / ports if possible

        # 3. Technology Fingerprinting
        if self.config.check_tech and initial_resp is not None:
            self.logger.log("Ejecutando reconocimiento de tecnologías, servidor y frameworks...", "PHASE", {"progress": 35})
            fingerprinter = TechnologyFingerprinter(
                headers=dict(initial_resp.headers),
                html_content=initial_resp.text,
                cookies=initial_resp.cookies.get_dict()
            )
            detected_tech, tech_findings = fingerprinter.fingerprint()
            self.technologies.extend(detected_tech)
            self.findings.extend(tech_findings)
            self.logger.log(f"Reconocimiento completado: {len(detected_tech)} tecnologías identificadas.", "INFO", {"progress": 45, "tech_count": len(detected_tech)})

        # 4. HTTP Security Headers Analysis
        if self.config.check_headers and initial_resp is not None:
            self.logger.log("Auditando cabeceras HTTP de seguridad (CSP, X-Frame-Options, HSTS)...", "PHASE", {"progress": 55})
            h_analyzer = HeadersAnalyzer(base_url=target_url, headers=dict(initial_resp.headers))
            _, hdr_findings = h_analyzer.analyze()
            self.findings.extend(hdr_findings)
            self.logger.log(f"Análisis de cabeceras completado ({len(hdr_findings)} hallazgos)", "INFO", {"progress": 60})

        # 5. TLS / Cryptographic Inspection
        if self.config.check_tls:
            self.logger.log("Evaluando certificados SSL/TLS, suites criptográficas y versiones de protocolo...", "PHASE", {"progress": 65})
            port = 443 if parsed.scheme == "https" or parsed.port is None else parsed.port
            tls_analyzer = TLSAnalyzer(host=domain, port=port, timeout=self.config.timeout_sec)
            tls_info, tls_findings = tls_analyzer.analyze()
            self.findings.extend(tls_findings)
            self.logger.log(f"Inspección TLS finalizada (Cifrado: {tls_info.get('cipher', 'N/A')})", "INFO", {"progress": 70})

        # 6. DNS & Email Security
        self.logger.log("Consultando registros DNS, validación de SPF/DMARC y comprobación de AXFR...", "PHASE", {"progress": 75})
        try:
            dns_analyzer = DNSAnalyzer(domain=domain, timeout=self.config.timeout_sec)
            _, dns_findings = dns_analyzer.analyze()
            self.findings.extend(dns_findings)
        except Exception as e:
            self.logger.log(f"Nota en resolución DNS: {str(e)}", "WARN")

        # 7. Safe Sensitive Exposure Scanning
        if self.config.deep_exposure_check and self.config.scan_mode == "active_safe":
            self.logger.log("Iniciando escaneo controlado de archivos y directorios expuestos (.env, .git, backups)...", "PHASE", {"progress": 82})
            exposure_scanner = ExposureScanner(requester=requester, base_url=target_url)
            exp_findings = exposure_scanner.scan()
            self.findings.extend(exp_findings)
            self.logger.log(f"Escaneo de rutas sensibles completado ({len(exp_findings)} hallazgos)", "INFO", {"progress": 88})

        # 8. Web App Active & Passive Checks (Cookies, Forms, CORS, Ports)
        if self.config.check_vulns and initial_resp is not None:
            self.logger.log("Ejecutando verificaciones de Cookies, CORS, puertos y scripts...", "PHASE", {"progress": 92})
            web_analyzer = WebAppAnalyzer(
                requester=requester,
                base_url=target_url,
                host=domain,
                raw_response=initial_resp
            )
            web_findings = web_analyzer.run_all_checks()
            self.findings.extend(web_findings)

        # 8b. Rastreo + pruebas activas de inyección (XSS reflejado, SQLi por errores, open redirect)
        tested_params = 0
        if (self.config.active_injection_checks and self.config.scan_mode == "active_safe"
                and initial_resp is not None):
            self.logger.log("Rastreando el sitio para descubrir parámetros y formularios...", "PHASE", {"progress": 94})
            try:
                seeds = list(self.config.seed_urls)
                if requester.post_login_url:
                    seeds.insert(0, requester.post_login_url)
                crawler = Crawler(requester, target_url, max_pages=self.config.max_pages,
                                  max_depth=self.config.crawl_depth, seed_urls=seeds, logger=self.logger)
                crawl_info = crawler.crawl()
                crawl_info["authenticated"] = authenticated
                self.logger.log(f"Rastreo: {crawl_info['pages_visited']} páginas, {crawl_info['injection_points']} puntos de inyección.", "INFO")
                if crawl_info["injection_points"] == 0:
                    self.logger.log("Sin parámetros que probar. Si la app requiere login, configurá cookie o credenciales; "
                                    "si es una SPA, agregá URLs semilla.", "WARN")
                else:
                    self.logger.log("Probando XSS reflejado, SQLi por errores y open redirect (no destructivo)...", "PHASE", {"progress": 96})
                    checker = InjectionChecker(requester, crawler.points, test_post=self.config.test_post_forms, logger=self.logger)
                    inj_findings = checker.run()
                    tested_params = checker.tested
                    crawl_info["parameters_tested"] = tested_params
                    self.findings.extend(inj_findings)
                    self.logger.log(f"Pruebas activas completadas: {tested_params} parámetros, {len(inj_findings)} hallazgos.", "INFO")
            except ScopeViolationError as sve:
                self.logger.log(f"Rastreo detenido por alcance: {sve}", "WARN")
            except Exception as e:
                self.logger.log(f"Error en rastreo/pruebas activas: {type(e).__name__}: {e}", "WARN")
        self._tested_params = tested_params

        # 9. Synthesize Inconclusive / Manual Audit Guidelines for non-testable families
        self._append_manual_validation_entries()

        end_time_iso = time.strftime("%Y-%m-%dT%H:%M:%S")
        duration = time.time() - start_timestamp

        # 10. Compute Summary Metrics
        summary = self._compute_summary(duration)
        if initial_resp is None:
            # FIX: antes un sitio inaccesible mostraba 86/100 "ACEPTABLE", como si estuviera bien
            summary["rating"] = "INCOMPLETO (sin respuesta HTTP)"
            summary["incomplete"] = True
            self.findings.insert(0, Finding(
                id="SCAN-INCOMPLETE", vuln_number=0,
                title="Auditoría incompleta: no hubo respuesta HTTP del objetivo",
                category="Estado del escaneo", severity=Severity.INFO, status=FindingStatus.INFO,
                affected_component=target_url,
                technical_description="No se pudo obtener la página principal (timeout, DNS, firewall o WAF). Solo se ejecutaron DNS/TLS/puertos; "
                                      "cabeceras, tecnologías, rastreo y pruebas activas NO se ejecutaron. El puntaje no es representativo.",
                evidence="Ver el log del escaneo para el error exacto.",
                impact="Resultado no concluyente.", remediation="Reintentar con mayor timeout, verificar el dominio o ejecutar desde otra red."))
        self.logger.log(f"Auditoría concluida con éxito en {round(duration, 2)}s. Score de Seguridad: {summary['security_score']}/100", "SUCCESS", {"progress": 100})

        return AuditReport(
            scan_id=self.scan_id,
            target_url=target_url,
            domain=domain,
            start_time=start_time_iso,
            end_time=end_time_iso,
            crawl_info=crawl_info,
            duration_seconds=duration,
            technologies=self.technologies,
            findings=self.findings,
            summary=summary,
            server_info=server_info,
            tls_info=tls_info,
            logs=self.logger.history
        )

    def _append_manual_validation_entries(self):
        """
        For vulnerabilities requiring destructive or deep stateful testing (e.g. BOLA, Race Conditions, Stored XSS, SQLi execution),
        include clean technical advisory entries categorized as 'REQUIERE_VALIDACION' so the auditor has concrete test steps.
        """
        # Selected high-value categories for advisory
        advisory_candidates = [1, 7, 8, 15, 76, 99, 100]
        existing_vuln_nums = {f.vuln_number for f in self.findings}

        for v_num in advisory_candidates:
            if v_num not in existing_vuln_nums:
                kb = VULNERABILITIES_KB.get(v_num)
                if kb:
                    self.findings.append(Finding(
                        id=f"MANUAL-{v_num:03d}",
                        vuln_number=v_num,
                        title=f"{kb['title']} (Verificación Manual Requerida)",
                        category=kb["chapter"],
                        severity=Severity.INFO,
                        status=FindingStatus.INCONCLUSIVE,
                        affected_component=kb["component"],
                        technical_description=f"{kb['description']} La verificación activa automatizada no se realiza de forma invasiva para preservar la integridad de los datos.",
                        evidence=(f"Se probaron {self._tested_params} parámetros con detección de errores SQL/XSS/redirect y no hubo hallazgos. "
                                  "Esto NO descarta variantes ciegas o de lógica: requiere pruebas manuales."
                                  if self._tested_params and v_num in (1, 2) else
                                  "Validación no invasiva: requiere pruebas con credenciales diferenciadas de usuario en entorno de pruebas."),
                        impact=kb["impact"],
                        remediation=kb["remediation"]
                    ))

    def _compute_summary(self, duration: float) -> Dict[str, Any]:
        counts = {
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
            "info": 0,
            "confirmed": 0,
            "potential": 0,
            "inconclusive": 0,
            "total": len(self.findings)
        }

        # Calculate a penalty-based Security Score (100 is best)
        penalty = 0
        for f in self.findings:
            if f.severity == Severity.CRITICAL:
                counts["critical"] += 1
                penalty += 25
            elif f.severity == Severity.HIGH:
                counts["high"] += 1
                penalty += 15
            elif f.severity == Severity.MEDIUM:
                counts["medium"] += 1
                penalty += 7
            elif f.severity == Severity.LOW:
                counts["low"] += 1
                penalty += 2
            else:
                counts["info"] += 1

            if f.status == FindingStatus.CONFIRMED:
                counts["confirmed"] += 1
            elif f.status == FindingStatus.POTENTIAL:
                counts["potential"] += 1
            elif f.status == FindingStatus.INCONCLUSIVE:
                counts["inconclusive"] += 1

        security_score = max(5, 100 - penalty)

        return {
            "counts": counts,
            "security_score": security_score,
            "rating": "CRÍTICO" if security_score < 40 else ("DEFICIENTE" if security_score < 70 else ("ACEPTABLE" if security_score < 90 else "EXCELENTE")),
            "duration_formatted": f"{round(duration, 1)}s"
        }
