"""
HTTP Security Headers Analyzer.
Audits response headers against modern hardening standards and identifies information leaks.
"""
from typing import List, Dict, Any, Tuple
import requests
from engine.models import Finding, Severity, FindingStatus
from engine.knowledge_base import VULNERABILITIES_KB

class HeadersAnalyzer:
    def __init__(self, base_url: str, headers: Dict[str, str]):
        self.base_url = base_url
        self.headers = {k.lower(): v for k, v in headers.items()}

    def analyze(self) -> Tuple[Dict[str, Any], List[Finding]]:
        findings: List[Finding] = []
        headers_status = {}

        # 1. Content-Security-Policy (CSP) - Mitigates XSS (SEC-002) & Clickjacking (SEC-024)
        csp = self.headers.get("content-security-policy")
        headers_status["csp"] = csp
        if not csp:
            kb = VULNERABILITIES_KB[2]
            findings.append(Finding(
                id="HDR-NO-CSP",
                vuln_number=2,
                title="Ausencia de Cabecera Content-Security-Policy (CSP)",
                category="HTTP y Comunicaciones",
                severity=Severity.MEDIUM,
                status=FindingStatus.CONFIRMED,
                affected_component="Cabecera HTTP Content-Security-Policy",
                technical_description="No se detectó la cabecera Content-Security-Policy. Sin una política CSP bien definida, el navegador no tiene defensas en profundidad para bloquear scripts no autorizados (XSS) o conexiones a dominios maliciosos.",
                evidence="Cabecera ausente en la respuesta HTTP",
                impact=kb["impact"],
                remediation="Implementar una política CSP restrictiva: Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none';"
            ))
        else:
            # Check for unsafe directives in existing CSP
            if "'unsafe-inline'" in csp and "nonce-" not in csp and "hash-" not in csp:
                findings.append(Finding(
                    id="HDR-CSP-UNSAFE-INLINE",
                    vuln_number=2,
                    title="Directiva Insegura 'unsafe-inline' en CSP",
                    category="HTTP y Comunicaciones",
                    severity=Severity.LOW,
                    status=FindingStatus.CONFIRMED,
                    affected_component="Content-Security-Policy: script-src",
                    technical_description="La política CSP permite 'unsafe-inline', lo que anula gran parte de la protección nativa contra inyecciones de Cross-Site Scripting (XSS).",
                    evidence=f"CSP: {csp}",
                    impact="Permite la ejecución de scripts insertados dinámicamente en el DOM.",
                    remediation="Eliminar 'unsafe-inline' y emplear nonces criptográficos o hashes SHA-256 para scripts en línea."
                ))

        # 2. X-Frame-Options & CSP frame-ancestors (Clickjacking SEC-024)
        x_frame = self.headers.get("x-frame-options", "").upper()
        headers_status["x_frame_options"] = x_frame
        has_frame_ancestors = csp and "frame-ancestors" in csp

        if not has_frame_ancestors and not x_frame:
            kb = VULNERABILITIES_KB[24]
            findings.append(Finding(
                id="HDR-CLICKJACKING",
                vuln_number=24,
                title="Vulnerabilidad de Clickjacking (Falta de Protección de Enmarcado)",
                category=kb["chapter"],
                severity=Severity.MEDIUM,
                status=FindingStatus.CONFIRMED,
                affected_component="Cabeceras X-Frame-Options y CSP frame-ancestors",
                technical_description="La aplicación no prohíbe ser incrustada dentro de elementos <iframe> o <frame> de dominios externos. Un atacante puede crear un portal engañoso superponiendo elementos invisibles sobre la interfaz legítima.",
                evidence="X-Frame-Options ausente y CSP no define directiva frame-ancestors",
                impact=kb["impact"],
                remediation=kb["remediation"]
            ))
        elif x_frame and x_frame not in ["DENY", "SAMEORIGIN"]:
            kb = VULNERABILITIES_KB[24]
            findings.append(Finding(
                id="HDR-XFO-INVALID",
                vuln_number=24,
                title="Configuración Débil de X-Frame-Options",
                category=kb["chapter"],
                severity=Severity.LOW,
                status=FindingStatus.CONFIRMED,
                affected_component="Cabecera X-Frame-Options",
                technical_description=f"El valor de X-Frame-Options ('{x_frame}') no es reconocido o es obsoleto (por ejemplo, ALLOW-FROM fue descartado por navegadores modernos).",
                evidence=f"X-Frame-Options: {x_frame}",
                impact="Falta de compatibilidad en navegadores actuales dejando abierta la posibilidad de enmarcado.",
                remediation="Configurar: X-Frame-Options: SAMEORIGIN o DENY, o preferir CSP: frame-ancestors 'self';"
            ))

        # 3. HTTP Strict Transport Security (HSTS - SEC-030 & SEC-033)
        hsts = self.headers.get("strict-transport-security")
        headers_status["hsts"] = hsts
        if self.base_url.startswith("https://"):
            if not hsts:
                kb = VULNERABILITIES_KB[33]
                findings.append(Finding(
                    id="HDR-NO-HSTS",
                    vuln_number=33,
                    title="Ausencia de Cabecera HSTS (Strict-Transport-Security)",
                    category=kb["chapter"],
                    severity=Severity.MEDIUM,
                    status=FindingStatus.CONFIRMED,
                    affected_component="Cabecera Strict-Transport-Security",
                    technical_description="El sitio sirve HTTPS pero no declara la cabecera HSTS. Los navegadores no recordarán forzar el cifrado de antemano, facilitando ataques de SSL Stripping en redes no seguras.",
                    evidence="Cabecera ausente en respuesta HTTPS",
                    impact=kb["impact"],
                    remediation=kb["remediation"]
                ))
            else:
                if "max-age" in hsts:
                    try:
                        # Extract max-age number
                        parts = [p.strip() for p in hsts.split(";")]
                        for p in parts:
                            if p.startswith("max-age="):
                                age = int(p.split("=")[1])
                                if age < 15552000: # Less than 180 days
                                    findings.append(Finding(
                                        id="HDR-HSTS-LOW-AGE",
                                        vuln_number=33,
                                        title="HSTS con max-age Insuficiente",
                                        category="HTTP y Comunicaciones",
                                        severity=Severity.LOW,
                                        status=FindingStatus.CONFIRMED,
                                        affected_component="Cabecera Strict-Transport-Security",
                                        technical_description=f"El valor de max-age es de {age} segundos (< 6 meses). Se recomienda un mínimo de 31536000 (1 año) para que el navegador mantenga la protección de forma persistente.",
                                        evidence=f"HSTS: {hsts}",
                                        impact="Expiración temprana de la política de protección HTTPS.",
                                        remediation="Ajustar a: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload"
                                    ))
                    except Exception:
                        pass

        # 4. X-Content-Type-Options (MIME Sniffing Prevention)
        xcto = self.headers.get("x-content-type-options")
        headers_status["x_content_type_options"] = xcto
        if not xcto or "nosniff" not in xcto.lower():
            findings.append(Finding(
                id="HDR-NO-NOSNIFF",
                vuln_number=43,
                title="Ausencia de Cabecera X-Content-Type-Options: nosniff",
                category="HTTP y Comunicaciones",
                severity=Severity.LOW,
                status=FindingStatus.CONFIRMED,
                affected_component="Cabecera X-Content-Type-Options",
                technical_description="Al no enviar 'nosniff', algunos navegadores antiguos o específicos intentarán adivinar el tipo de contenido (MIME-sniffing), lo que puede transformar archivos multimedia en ejecutables HTML/JS.",
                evidence="Cabecera ausente o sin 'nosniff'",
                impact="Riesgo de ejecución de código si se permiten cargas de archivos estáticos.",
                remediation="Añadir cabecera: X-Content-Type-Options: nosniff"
            ))

        # 5. Information Disclosure in Headers (SEC-043)
        server_val = self.headers.get("server")
        powered_val = self.headers.get("x-powered-by")
        asp_val = self.headers.get("x-aspnet-version")
        headers_status["server"] = server_val
        headers_status["x_powered_by"] = powered_val

        leak_details = []
        if server_val and any(char.isdigit() for char in server_val):
            leak_details.append(f"Server: {server_val}")
        if powered_val:
            leak_details.append(f"X-Powered-By: {powered_val}")
        if asp_val:
            leak_details.append(f"X-AspNet-Version: {asp_val}")

        if leak_details:
            kb = VULNERABILITIES_KB[43]
            findings.append(Finding(
                id="HDR-SERVER-DISCLOSURE",
                vuln_number=43,
                title="Divulgación de Tecnologías y Versiones en Cabeceras HTTP",
                category=kb["chapter"],
                severity=Severity.LOW,
                status=FindingStatus.CONFIRMED,
                affected_component="Banners HTTP (Server / X-Powered-By)",
                technical_description="El servidor HTTP revela abiertamente nombres de software, sistemas o versiones exactas en las cabeceras de respuesta. Esta información acelera el reconocimiento por parte de atacantes.",
                evidence=", ".join(leak_details),
                impact=kb["impact"],
                remediation=kb["remediation"]
            ))

        # 6. Referrer-Policy
        ref_pol = self.headers.get("referrer-policy")
        headers_status["referrer_policy"] = ref_pol
        if not ref_pol:
            findings.append(Finding(
                id="HDR-NO-REFERRER",
                vuln_number=43,
                title="Cabecera Referrer-Policy no Establecida",
                category="HTTP y Comunicaciones",
                severity=Severity.INFO,
                status=FindingStatus.CONFIRMED,
                affected_component="Cabecera Referrer-Policy",
                technical_description="Al navegar hacia enlaces externos, el navegador podría transmitir la URL completa de origen (incluyendo tokens o parámetros privados en el query string) en la cabecera Referer.",
                evidence="Cabecera ausente",
                impact="Fuga involuntaria de parámetros de consulta a sitios externos.",
                remediation="Configurar: Referrer-Policy: strict-origin-when-cross-origin o no-referrer"
            ))

        return headers_status, findings
