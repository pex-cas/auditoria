"""HTTP client with explicit target scope, bounded retries and request pacing."""
import threading
import time
import urllib.parse
from typing import Optional, Tuple

import requests


class ScopeViolationError(Exception):
    """Raised when a request or redirect leaves the configured target scope."""


class ScanDeadlineExceeded(TimeoutError):
    """Raised when the configured total scan deadline has elapsed."""


class RateLimiter:
    """Thread-safe request spacing limiter (requests/second)."""

    def __init__(self, max_per_second: float = 3.0):
        if max_per_second <= 0:
            raise ValueError("rate_limit debe ser mayor que cero")
        self.interval = 1.0 / max_per_second
        self._next_allowed = 0.0
        self._lock = threading.Lock()

    def wait(self) -> None:
        with self._lock:
            now = time.monotonic()
            delay = max(0.0, self._next_allowed - now)
            if delay:
                time.sleep(delay)
            self._next_allowed = time.monotonic() + self.interval


def _norm_host(host: str) -> str:
    return (host or "").lower().rstrip(".").encode("idna").decode("ascii")


class SafeRequester:
    RETRYABLE_METHODS = {"GET", "HEAD", "OPTIONS"}
    RETRYABLE_ERRORS = (
        requests.exceptions.Timeout,
        requests.exceptions.ConnectionError,
    )

    def __init__(
        self,
        base_url: str,
        rate_limit: float = 3.0,
        timeout: float = 8.0,
        max_redirects: int = 5,
        max_retries: int = 3,
        backoff_factor: float = 0.25,
        max_backoff: float = 2.0,
        max_duration_sec: Optional[float] = None,
        cookies: str = "",
        extra_headers: Optional[dict] = None,
    ):
        parsed = urllib.parse.urlsplit(base_url)
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            raise ValueError("base_url debe ser una URL HTTP/HTTPS válida")
        if timeout <= 0 or max_redirects < 0 or max_retries < 0:
            raise ValueError("timeout debe ser positivo y los límites no negativos")

        self.base_url = base_url.rstrip("/") + "/"
        self.parsed_base = parsed
        self.base_host = _norm_host(parsed.hostname)
        self.base_port = parsed.port or (443 if parsed.scheme == "https" else 80)
        self.rate_limiter = RateLimiter(rate_limit)
        self.timeout = float(timeout)
        self.max_redirects = max_redirects
        self.max_retries = max_retries
        self.backoff_factor = max(0.0, backoff_factor)
        self.max_backoff = max(0.0, max_backoff)
        self.deadline = (time.monotonic() + max_duration_sec) if max_duration_sec else None
        self.post_login_url = None

        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "CyberSecAudit/2.0 (authorized security assessment)",
            "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
            "Accept-Language": "es-AR,es;q=0.9,en;q=0.8",
        })
        if extra_headers:
            self.session.headers.update(extra_headers)
        for part in (cookies or "").split(";"):
            if "=" in part:
                key, value = part.strip().split("=", 1)
                if key.strip():
                    self.session.cookies.set(key.strip(), value.strip(), domain=self.base_host)

    def _check_deadline(self) -> None:
        if self.deadline is not None and time.monotonic() >= self.deadline:
            raise ScanDeadlineExceeded("Se alcanzó el tiempo máximo configurado para la auditoría.")

    def is_in_scope(self, url: str) -> bool:
        try:
            parsed = urllib.parse.urlsplit(url)
            if not parsed.netloc:
                return True
            if parsed.scheme and parsed.scheme not in ("http", "https"):
                return False
            host = _norm_host(parsed.hostname or "")
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
            host_ok = host == self.base_host or host.endswith("." + self.base_host)
            # Same host tree; permit normal HTTP/HTTPS ports and the configured origin's port.
            port_ok = port in (80, 443, self.base_port)
            return bool(host_ok and port_ok)
        except (TypeError, ValueError, UnicodeError):
            return False

    def _request_once(self, method: str, url: str, **kwargs) -> requests.Response:
        self._check_deadline()
        self.rate_limiter.wait()
        self._check_deadline()
        return self.session.request(method, url, allow_redirects=False, **kwargs)

    def _request_with_retry(self, method: str, url: str, **kwargs) -> requests.Response:
        attempts = self.max_retries + 1 if method in self.RETRYABLE_METHODS else 1
        for attempt in range(attempts):
            self._check_deadline()
            try:
                return self._request_once(method, url, **kwargs)
            except self.RETRYABLE_ERRORS:
                if attempt + 1 >= attempts:
                    raise
                delay = min(self.backoff_factor * (2 ** attempt), self.max_backoff)
                if self.deadline is not None:
                    remaining = self.deadline - time.monotonic()
                    if remaining <= 0:
                        raise ScanDeadlineExceeded("Se alcanzó el tiempo máximo de auditoría.")
                    delay = min(delay, remaining)
                if delay > 0:
                    time.sleep(delay)
        raise RuntimeError("La solicitud finalizó sin respuesta.")

    def request(self, method: str, url: str, allow_redirects: bool = True, **kwargs) -> requests.Response:
        method = method.upper()
        current_url = urllib.parse.urljoin(self.base_url, url)
        if not self.is_in_scope(current_url):
            raise ScopeViolationError(f"Destino fuera del alcance autorizado: {current_url}")

        request_kwargs = dict(kwargs)
        request_kwargs.setdefault("timeout", self.timeout)
        request_kwargs.setdefault("verify", True)
        redirects = 0

        while True:
            response = self._request_with_retry(method, current_url, **request_kwargs)
            if not allow_redirects or not response.is_redirect:
                return response
            location = response.headers.get("Location")
            if not location:
                return response
            destination = urllib.parse.urljoin(current_url, location)
            if not self.is_in_scope(destination):
                # Return the redirect response, but never follow an out-of-scope Location.
                return response
            if redirects >= self.max_redirects:
                response.close()
                raise requests.exceptions.TooManyRedirects(
                    f"Se superó el máximo de {self.max_redirects} redirecciones."
                )

            status = response.status_code
            response.close()
            if status == 303 or (status in (301, 302) and method == "POST"):
                method = "GET"
                request_kwargs.pop("data", None)
                request_kwargs.pop("json", None)
                request_kwargs.pop("params", None)
            current_url = destination
            redirects += 1

    def login(self, login_url: str, username: str, password: str,
              user_field: str = "username", pass_field: str = "password") -> Tuple[bool, str]:
        from bs4 import BeautifulSoup
        page = self.get(login_url)
        soup = BeautifulSoup(page.text or "", "html.parser")
        form = next((f for f in soup.find_all("form") if
                     f.find("input", {"type": "password"}) or f.find("input", {"name": pass_field})), None)
        if form is None:
            return False, "No se encontró un formulario de login en la URL indicada."
        data = {}
        for inp in form.find_all(["input", "select", "textarea"]):
            name = inp.get("name")
            if name:
                data[name] = inp.get("value", "")
        data[user_field] = username
        data[pass_field] = password
        action = urllib.parse.urljoin(page.url, form.get("action") or login_url)
        if (form.get("method") or "post").upper() == "GET":
            response = self.get(action, params=data)
        else:
            response = self.post(action, data=data)
        still_login = BeautifulSoup(response.text or "", "html.parser").find("input", {"type": "password"}) is not None
        if still_login:
            return False, "El formulario de login sigue visible; verificá credenciales y campos."
        self.post_login_url = response.url
        return True, f"Respuesta HTTP {response.status_code}. Aterrizaje: {response.url}"

    def get(self, url: str, **kwargs) -> requests.Response:
        return self.request("GET", url, **kwargs)

    def head(self, url: str, **kwargs) -> requests.Response:
        return self.request("HEAD", url, **kwargs)

    def post(self, url: str, **kwargs) -> requests.Response:
        return self.request("POST", url, **kwargs)

    def options(self, url: str, **kwargs) -> requests.Response:
        return self.request("OPTIONS", url, **kwargs)

    def close(self) -> None:
        self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
