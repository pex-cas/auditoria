"""
Pruebas activas de DETECCIÓN (no explotación) sobre los puntos de inyección encontrados por el crawler.

  - XSS reflejado: se envía un marcador inerte con <etiqueta-inventada> y comillas; si vuelve SIN codificar
    en una respuesta HTML, el navegador interpretaría HTML inyectado.
  - SQLi basada en errores: se agrega una comilla y se buscan firmas de error de motores SQL que NO
    estaban en la respuesta base. Además, una comparación booleana simple (AND verdadero vs AND falso).
  - Open redirect: parámetros típicos (next, url, redirect...) con un dominio canario reservado (.example).

Nada de esto extrae datos, modifica la base ni ejecuta código. Solo observa cómo responde la aplicación.
Los formularios POST se omiten salvo que se active test_post_forms (pueden crear registros).
"""
import random
import re
import string
import urllib.parse
from typing import List, Dict, Any

from engine.models import Finding, Severity, FindingStatus
from engine.knowledge_base import VULNERABILITIES_KB
from engine.scope import SafeRequester, ScopeViolationError
from engine.crawler import InjectionPoint

SQL_ERROR_SIGNATURES = [
    (r"you have an error in your sql syntax", "MySQL/MariaDB"),
    (r"warning:\s*mysqli?_", "MySQL (PHP)"),
    (r"mysqli?_sql_exception|mysql_fetch|supplied argument is not a valid mysql", "MySQL (PHP)"),
    (r"unclosed quotation mark after the character string", "Microsoft SQL Server"),
    (r"microsoft ole db provider|odbc sql server driver|\[sql server\]", "Microsoft SQL Server"),
    (r"pg_query\(\)|pg::syntaxerror|psql:|unterminated quoted string at or near|syntax error at or near", "PostgreSQL"),
    (r"sqlite_error|sqlite3?\.operationalerror|sqlite3::sqlexception|near \".{0,20}\": syntax error", "SQLite"),
    (r"ora-\d{5}|oracle error|quoted string not properly terminated", "Oracle"),
    (r"sqlstate\[[0-9a-z]+\]|sqlexception|jdbc|hibernate", "SQL genérico (PDO/JDBC)"),
    (r"syntax error.{0,40}(sql|query)|unexpected end of sql command", "SQL genérico"),
]
SQL_ERROR_RE = [(re.compile(p, re.I), name) for p, name in SQL_ERROR_SIGNATURES]

REDIRECT_PARAM_NAMES = {"next", "url", "redirect", "redirect_to", "redirect_uri", "return", "returnurl", "return_url",
                        "returnto", "goto", "dest", "destination", "continue", "redir", "target", "to", "link", "forward"}
CANARY_REDIRECT_HOST = "audit-canary.example"

# Parámetros que no tiene sentido tocar (rompen la sesión o son tokens)
SKIP_PARAMS = re.compile(r"(csrf|token|nonce|authenticity|viewstate|captcha|submit|login|logout)", re.I)


def _rand() -> str:
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=7))


class InjectionChecker:
    def __init__(self, requester: SafeRequester, points: List[InjectionPoint], test_post: bool = False,
                 max_tests: int = 80, logger=None):
        self.req = requester
        self.points = points
        self.test_post = test_post
        self.max_tests = max_tests
        self.log = logger
        self.findings: List[Finding] = []
        self.tested = 0
        self._reported = set()

    def _say(self, msg, level="INFO"):
        if self.log:
            self.log.log(msg, level)

    # -------------------- envío ------------------------------------
    def _send(self, point: InjectionPoint, params: Dict[str, str], follow: bool = True):
        if point["method"] == "POST":
            return self.req.post(point["url"], data=params, allow_redirects=follow)
        return self.req.get(point["url"], params=params, allow_redirects=follow)

    def _is_html(self, resp) -> bool:
        return "html" in resp.headers.get("Content-Type", "").lower()

    def _dedupe(self, kind: str, point, param) -> bool:
        key = (kind, point["url"], param)
        if key in self._reported:
            return False
        self._reported.add(key)
        return True

    # -------------------- ejecución --------------------------------
    def run(self) -> List[Finding]:
        budget_points = [p for p in self.points if p["method"] == "GET" or self.test_post]
        skipped_post = len(self.points) - len(budget_points)
        if skipped_post:
            self._say(f"{skipped_post} formulario(s) POST omitidos (activá 'probar formularios POST' solo en laboratorio).", "INFO")

        for point in budget_points:
            for pname in list(point["params"].keys()):
                if self.tested >= self.max_tests:
                    self._say(f"Límite de {self.max_tests} parámetros probados alcanzado.", "WARN")
                    return self.findings
                if SKIP_PARAMS.search(pname):
                    continue
                self.tested += 1
                try:
                    baseline = self._send(point, dict(point["params"]))
                    self._check_xss(point, pname, baseline)
                    self._check_sqli(point, pname, baseline)
                    if pname.lower() in REDIRECT_PARAM_NAMES:
                        self._check_open_redirect(point, pname)
                except ScopeViolationError:
                    continue
                except Exception as e:
                    self._say(f"Prueba omitida en {point['url']} ({pname}): {type(e).__name__}", "WARN")
        return self.findings

    # -------------------- XSS reflejado ----------------------------
    def _check_xss(self, point, pname, baseline):
        tag = "zq" + _rand()
        canary = "cs" + _rand()
        payload = f"{canary}\"'<{tag}>"
        params = dict(point["params"]); params[pname] = payload
        resp = self._send(point, params)
        if not self._is_html(resp) or canary not in resp.text:
            return
        body = resp.text
        kb = VULNERABILITIES_KB[4]
        raw_tag = f"<{tag}>" in body
        raw_quote = f"{canary}\"" in body
        if raw_tag and self._dedupe("xss", point, pname):
            idx = body.find(f"<{tag}>")
            snippet = body[max(0, idx - 60): idx + len(tag) + 40].replace("\n", " ")
            self.findings.append(Finding(
                id=f"XSS-REFLECTED-{len(self.findings)+1}", vuln_number=4,
                title=f"XSS Reflejado en parámetro '{pname}'",
                category=kb["chapter"], severity=Severity.HIGH, status=FindingStatus.CONFIRMED,
                affected_component=f"{point['method']} {point['url']} (parámetro: {pname})",
                technical_description="El valor enviado en el parámetro vuelve en la respuesta HTML sin codificar los caracteres < y >. "
                                      "Un atacante puede construir un enlace que ejecute JavaScript en el navegador de quien lo abra.",
                evidence=f"Marcador enviado: {payload}\nEl marcador <{tag}> apareció SIN codificar en la respuesta:\n...{snippet}...",
                impact=kb["impact"], remediation=kb["remediation"],
                references=["CWE-79", "OWASP A03:2021-Injection"]))
        elif raw_quote and self._dedupe("xss-attr", point, pname):
            self.findings.append(Finding(
                id=f"XSS-REFLECTED-ATTR-{len(self.findings)+1}", vuln_number=4,
                title=f"Posible XSS reflejado (comillas sin escapar) en '{pname}'",
                category=kb["chapter"], severity=Severity.MEDIUM, status=FindingStatus.POTENTIAL,
                affected_component=f"{point['method']} {point['url']} (parámetro: {pname})",
                technical_description="El valor se refleja con las comillas dobles sin escapar. Si cae dentro de un atributo HTML, "
                                      "permite cerrar el atributo e inyectar manejadores de eventos.",
                evidence=f"Marcador enviado: {payload}\nReflejado con comilla doble literal junto al marcador.",
                impact=kb["impact"], remediation=kb["remediation"], references=["CWE-79"]))

    # -------------------- SQLi -------------------------------------
    def _find_sql_error(self, text: str):
        for rx, name in SQL_ERROR_RE:
            m = rx.search(text)
            if m:
                return name, m.group(0)
        return None, None

    def _check_sqli(self, point, pname, baseline):
        base_val = point["params"][pname]
        base_err, _ = self._find_sql_error(baseline.text or "")
        kb = VULNERABILITIES_KB[1]

        # 1) Error-based: comilla simple y doble
        for quote in ("'", '"'):
            params = dict(point["params"]); params[pname] = base_val + quote
            resp = self._send(point, params)
            engine, sig = self._find_sql_error(resp.text or "")
            if engine and not base_err and self._dedupe("sqli", point, pname):
                idx = (resp.text or "").lower().find(sig.lower())
                snippet = (resp.text or "")[max(0, idx - 40): idx + len(sig) + 80].replace("\n", " ")
                self.findings.append(Finding(
                    id=f"SQLI-ERROR-{len(self.findings)+1}", vuln_number=1,
                    title=f"SQL Injection (basada en errores) en parámetro '{pname}' [{engine}]",
                    category=kb["chapter"], severity=Severity.CRITICAL, status=FindingStatus.CONFIRMED,
                    affected_component=f"{point['method']} {point['url']} (parámetro: {pname})",
                    technical_description=f"Al agregar una comilla ({quote}) al valor del parámetro, la aplicación devuelve un error del motor {engine}. "
                                          "Esto indica que la entrada se concatena directamente en la consulta SQL.",
                    evidence=f"Valor enviado: {base_val}{quote}\nHTTP {resp.status_code}. Fragmento de la respuesta:\n...{snippet}...\n(La respuesta base NO contenía este error.)",
                    impact=kb["impact"], remediation=kb["remediation"],
                    references=["CWE-89", "OWASP A03:2021-Injection"]))
                return

        # 2) Booleana: AND verdadero debe parecerse a la base, AND falso debe diferir
        if not base_val:
            return
        def body_len(val):
            p = dict(point["params"]); p[pname] = val
            r = self._send(point, p)
            return len(r.text or ""), r.status_code
        for t, f in (("' AND '1'='1", "' AND '1'='2"), (" AND 1=1", " AND 1=2")):
            lt, st = body_len(base_val + t)
            lf, sf = body_len(base_val + f)
            lb = len(baseline.text or "")
            if abs(lt - lb) <= max(20, lb * 0.02) and abs(lf - lb) > max(40, lb * 0.05) and st == baseline.status_code \
                    and self._dedupe("sqli-bool", point, pname):
                self.findings.append(Finding(
                    id=f"SQLI-BOOL-{len(self.findings)+1}", vuln_number=1,
                    title=f"Posible SQL Injection (diferencia booleana) en '{pname}'",
                    category=kb["chapter"], severity=Severity.HIGH, status=FindingStatus.POTENTIAL,
                    affected_component=f"{point['method']} {point['url']} (parámetro: {pname})",
                    technical_description="Una condición lógica verdadera deja la respuesta igual a la original y una falsa la cambia de forma notable. "
                                          "Ese comportamiento es típico de una consulta SQL manipulable. Requiere validación manual.",
                    evidence=f"base={lb} bytes | '{t.strip()}'={lt} bytes | '{f.strip()}'={lf} bytes",
                    impact=kb["impact"], remediation=kb["remediation"], references=["CWE-89"]))
                return

    # -------------------- Open redirect ----------------------------
    def _check_open_redirect(self, point, pname):
        params = dict(point["params"]); params[pname] = f"https://{CANARY_REDIRECT_HOST}/audit"
        resp = self._send(point, params, follow=False)
        loc = resp.headers.get("Location", "")
        host = urllib.parse.urlparse(loc).netloc.lower()
        if resp.is_redirect and host == CANARY_REDIRECT_HOST and self._dedupe("redir", point, pname):
            kb = VULNERABILITIES_KB[20]
            self.findings.append(Finding(
                id=f"OPEN-REDIRECT-{len(self.findings)+1}", vuln_number=20,
                title=f"Open Redirect en parámetro '{pname}'",
                category=kb["chapter"], severity=Severity.MEDIUM, status=FindingStatus.CONFIRMED,
                affected_component=f"{point['method']} {point['url']} (parámetro: {pname})",
                technical_description="La aplicación redirige a cualquier dominio externo indicado en el parámetro, "
                                      "lo que permite usar el sitio legítimo para campañas de phishing.",
                evidence=f"{pname}=https://{CANARY_REDIRECT_HOST}/audit -> HTTP {resp.status_code}, Location: {loc}",
                impact=kb["impact"], remediation=kb["remediation"], references=["CWE-601"]))
