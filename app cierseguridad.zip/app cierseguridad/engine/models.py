"""
Core data models and types for the Security Audit Engine.
"""
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import List, Dict, Optional, Any
import datetime

class Severity(str, Enum):
    CRITICAL = "CRÍTICA"
    HIGH = "ALTA"
    MEDIUM = "MEDIA"
    LOW = "BAJA"
    INFO = "INFORMACIÓN"

class FindingStatus(str, Enum):
    CONFIRMED = "CONFIRMADA"
    POTENTIAL = "POTENCIAL"
    INCONCLUSIVE = "REQUIERE_VALIDACION"
    INFO = "INFORMATIVO"

@dataclass
class Finding:
    id: str
    vuln_number: int  # 1 to 300 reference from the taxonomy
    title: str
    category: str
    severity: Severity
    status: FindingStatus
    affected_component: str
    technical_description: str
    evidence: str
    impact: str
    remediation: str
    references: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data['severity'] = self.severity.value
        data['status'] = self.status.value
        return data

@dataclass
class TechFingerprint:
    name: str
    category: str  # Server, CMS, Framework, Language, CDN/Proxy, OS
    version: Optional[str] = None
    confidence: str = "ALTA" # ALTA, MEDIA, BAJA
    evidence: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class ScanConfig:
    target_url: str
    scan_mode: str = "active_safe"  # "passive" or "active_safe"
    max_requests_per_sec: float = 3.0
    timeout_sec: int = 8
    max_duration_sec: int = 180
    allowed_domains: List[str] = field(default_factory=list)
    authorized_consent: bool = False
    deep_exposure_check: bool = True
    check_tls: bool = True
    check_headers: bool = True
    check_tech: bool = True
    check_vulns: bool = True
    # --- Rastreo y pruebas activas (NUEVO) ---
    active_injection_checks: bool = True   # XSS reflejado, SQLi por errores, open redirect
    crawl_depth: int = 2
    max_pages: int = 40
    seed_urls: List[str] = field(default_factory=list)  # URLs extra (SPAs, APIs, páginas ocultas)
    test_post_forms: bool = False          # Los POST pueden cambiar estado: solo en laboratorio
    # --- Autenticación (NUEVO) ---
    cookies: str = ""                      # "PHPSESSID=abc; security=low"
    extra_headers: Dict[str, str] = field(default_factory=dict)  # ej. Authorization: Bearer ...
    login_url: str = ""
    login_username: str = ""
    login_password: str = ""
    login_user_field: str = "username"
    login_pass_field: str = "password"

@dataclass
class AuditReport:
    scan_id: str
    target_url: str
    domain: str
    start_time: str
    end_time: str
    duration_seconds: float
    technologies: List[TechFingerprint] = field(default_factory=list)
    findings: List[Finding] = field(default_factory=list)
    summary: Dict[str, Any] = field(default_factory=dict)
    server_info: Dict[str, Any] = field(default_factory=dict)
    tls_info: Dict[str, Any] = field(default_factory=dict)
    logs: List[str] = field(default_factory=list)
    crawl_info: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scan_id": self.scan_id,
            "target_url": self.target_url,
            "domain": self.domain,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_seconds": round(self.duration_seconds, 2),
            "technologies": [t.to_dict() for t in self.technologies],
            "findings": [f.to_dict() for f in self.findings],
            "summary": self.summary,
            "server_info": self.server_info,
            "tls_info": self.tls_info,
            "logs": self.logs,
            "crawl_info": self.crawl_info
        }
