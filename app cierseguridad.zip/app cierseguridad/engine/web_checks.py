"""
Safe Web Application Checks & Heuristics:
- Cookie Security Audit (HttpOnly, Secure, SameSite)
- Form Anti-CSRF Token Heuristics
- Safe CORS Misconfiguration Probes
- Safe Host Header Injection Probes
- Client-Side Scripts Inspection (DOM XSS sinks, SRI, Prototype Pollution)
- Safe Non-Destructive Port Checks for Exposed DBs & Administration Ports
"""
import re
import socket
import urllib.parse
from typing import List, Dict, Any, Tuple
from bs4 import BeautifulSoup
import requests

from engine.scope import SafeRequester
from engine.models import Finding, Severity, FindingStatus
from engine.knowledge_base import VULNERABILITIES_KB

class WebAppAnalyzer:
    def __init__(self, requester: SafeRequester, base_url: str, host: str, raw_response: requests.Response):
        self.requester = requester
        self.base_url = base_url
        self.host = host
        self.response = raw_response
        self.html_content = raw_response.text or ""
        self.soup = BeautifulSoup(self.html_content, 'html.parser') if self.html_content else None

    def run_all_checks(self) -> List[Finding]:
        findings: List[Finding] = []
        findings.extend(self._audit_cookies())
        findings.extend(self._audit_forms_csrf())
        findings.extend(self._audit_cors_policy())
        findings.extend(self._audit_host_header())
        findings.extend(self._audit_client_scripts())
        findings.extend(self._audit_browser_policy_headers())
        findings.extend(self._check_exposed_service_ports())
        return findings

    def _audit_browser_policy_headers(self) -> List[Finding]:
        """Passive checks for additional browser-side security and cache controls."""
        findings: List[Finding] = []
        headers = {k.lower(): v for k, v in self.response.headers.items()}

        if "permissions-policy" not in headers:
            findings.append(Finding(
                id="HTTP-PERMISSIONS-POLICY-MISSING", vuln_number=0,
                title="Falta la cabecera Permissions-Policy",
                category="Configuración HTTP", severity=Severity.LOW,
                status=FindingStatus.POTENTIAL,
                affected_component="Cabecera Permissions-Policy",
                technical_description=(
                    "La respuesta no define una Permissions-Policy. El navegador conserva "
                    "los valores predeterminados para funciones como cámara, micrófono y geolocalización. "
                    "La ausencia no demuestra por sí sola una vulnerabilidad explotable."
                ),
                evidence="Permissions-Policy no aparece en la respuesta HTTP inicial.",
                impact="Funciones del navegador podrían quedar habilitadas en contextos donde no son necesarias.",
                remediation="Definir una política restrictiva según las funciones que realmente utiliza la aplicación; por ejemplo, deshabilitar cámara y micrófono si no se necesitan."
            ))

        if "referrer-policy" not in headers:
            findings.append(Finding(
                id="HTTP-REFERRER-POLICY-MISSING", vuln_number=0,
                title="Falta la cabecera Referrer-Policy",
                category="Configuración HTTP", severity=Severity.LOW,
                status=FindingStatus.POTENTIAL,
                affected_component="Cabecera Referrer-Policy",
                technical_description="No se observó una política explícita para controlar qué información de referencia envía el navegador al navegar a otros sitios.",
                evidence="Referrer-Policy no aparece en la respuesta HTTP inicial.",
                impact="La URL de origen podría revelar rutas o parámetros a destinos externos, según el contexto y el navegador.",
                remediation="Configurar strict-origin-when-cross-origin o una política más restrictiva compatible con la aplicación."
            ))

        cache_control = headers.get("cache-control", "").lower()
        content_type = headers.get("content-type", "").lower()
        looks_sensitive = any(token in (self.response.url or self.base_url).lower() for token in ("/account", "/admin", "/profile", "/dashboard"))
        if looks_sensitive and not any(token in cache_control for token in ("no-store", "private")):
            findings.append(Finding(
                id="HTTP-SENSITIVE-CACHE-CONTROL", vuln_number=0,
                title="Revisar política de caché en una ruta potencialmente sensible",
                category="Configuración HTTP", severity=Severity.INFO,
                status=FindingStatus.INCONCLUSIVE,
                affected_component=self.base_url,
                technical_description="La URL inicial parece corresponder a una zona de cuenta o administración, pero la respuesta no incluye directivas Cache-Control no-store o private.",
                evidence=f"Cache-Control: {headers.get('cache-control', '(ausente)')} | Content-Type: {content_type or '(ausente)'}",
                impact="Si la respuesta contiene datos privados, una política de caché permisiva podría permitir que se almacenen en cachés compartidas o locales.",
                remediation="Confirmar si la respuesta contiene información privada y configurar Cache-Control: no-store para contenido sensible."
            ))

        server_header = headers.get("server", "")
        if server_header and any(ch.isdigit() for ch in server_header):
            findings.append(Finding(
                id="HTTP-SERVER-VERSION-DISCLOSURE", vuln_number=0,
                title="La cabecera Server podría revelar versión del servidor",
                category="Divulgación de información", severity=Severity.INFO,
                status=FindingStatus.POTENTIAL,
                affected_component="Cabecera Server",
                technical_description="La cabecera Server contiene una cadena con dígitos, lo que podría revelar información de versión útil para inventario y gestión de parches.",
                evidence=f"Server: {server_header[:200]}",
                impact="La información de versión puede facilitar la identificación de componentes; no demuestra que estén desactualizados.",
                remediation="Reducir la información de versión expuesta y mantener el servidor actualizado."
            ))
        return findings

    # --- 1. COOKIE SECURITY AUDIT (SEC-006, SEC-010, SEC-011) ---
    def _audit_cookies(self) -> List[Finding]:
        findings = []
        # Parse Set-Cookie headers from the original response
        # In requests, raw Set-Cookie headers can be extracted
        cookie_headers = []
        if 'Set-Cookie' in self.response.raw.headers:
            cookie_headers = self.response.raw.headers.getlist('Set-Cookie')
        elif 'set-cookie' in self.response.headers:
            cookie_headers = [self.response.headers['set-cookie']]

        session_cookie_names = ["session", "phpsessid", "jsessionid", "aspsessionid", "token", "auth", "jwt", "sid", "connect.sid"]

        for cookie_str in cookie_headers:
            cookie_parts = [p.strip() for p in cookie_str.split(";")]
            if not cookie_parts:
                continue
            name_val = cookie_parts[0].split("=", 1)
            cookie_name = name_val[0].strip()
            lower_name = cookie_name.lower()
            flags = [p.lower() for p in cookie_parts[1:]]

            is_session = any(sess in lower_name for sess in session_cookie_names)
            is_secure = "secure" in flags
            is_httponly = "httponly" in flags
            samesite_val = None
            for f in flags:
                if f.startswith("samesite"):
                    samesite_val = f.split("=")[-1] if "=" in f else "lax"

            # Check Missing HttpOnly on Session Cookies (SEC-010)
            if is_session and not is_httponly:
                kb = VULNERABILITIES_KB[10]
                findings.append(Finding(
                    id=f"COOKIE-NO-HTTPONLY-{cookie_name}",
                    vuln_number=10,
                    title=f"Cookie de Sesión sin Bandera HttpOnly ({cookie_name})",
                    category=kb["chapter"],
                    severity=Severity.HIGH,
                    status=FindingStatus.CONFIRMED,
                    affected_component=f"Cookie: {cookie_name}",
                    technical_description=f"La cookie '{cookie_name}' parece gestionar el estado de sesión o autenticación, pero carece del atributo HttpOnly. Cualquier script malicioso ejecutado en el navegador (XSS) podrá leerla directamente mediante document.cookie y secuestrar la sesión.",
                    evidence=f"Set-Cookie: {cookie_str}",
                    impact=kb["impact"],
                    remediation="Configurar la bandera HttpOnly en la creación de la cookie en el servidor de aplicaciones."
                ))

            # Check Missing Secure flag over HTTPS (SEC-010)
            if self.base_url.startswith("https://") and not is_secure:
                kb = VULNERABILITIES_KB[10]
                findings.append(Finding(
                    id=f"COOKIE-NO-SECURE-{cookie_name}",
                    vuln_number=10,
                    title=f"Cookie Transmitida sin Atributo Secure ({cookie_name})",
                    category=kb["chapter"],
                    severity=Severity.MEDIUM,
                    status=FindingStatus.CONFIRMED,
                    affected_component=f"Cookie: {cookie_name}",
                    technical_description=f"La cookie '{cookie_name}' fue emitida sin la bandera 'Secure'. El navegador podría transmitirla en conexiones HTTP no cifradas en texto claro ante solicitudes de recursos mixtos.",
                    evidence=f"Set-Cookie: {cookie_str}",
                    impact=kb["impact"],
                    remediation="Establecer la directiva Secure en todas las cookies emitidas bajo conexiones HTTPS."
                ))

            # Check SameSite Missing / Lax / Strict (SEC-006)
            if not samesite_val or samesite_val == "none":
                kb = VULNERABILITIES_KB[6]
                findings.append(Finding(
                    id=f"COOKIE-NO-SAMESITE-{cookie_name}",
                    vuln_number=6,
                    title=f"Cookie sin Restricción SameSite Adecuada ({cookie_name})",
                    category=kb["chapter"],
                    severity=Severity.LOW,
                    status=FindingStatus.CONFIRMED,
                    affected_component=f"Cookie: {cookie_name}",
                    technical_description=f"La cookie '{cookie_name}' no define una política SameSite restrictiva (Lax o Strict), facilitando el envío involuntario de cookies en peticiones Cross-Origin (CSRF).",
                    evidence=f"SameSite={samesite_val if samesite_val else 'No configurado'}",
                    impact=kb["impact"],
                    remediation="Configurar SameSite=Lax (para navegación habitual) o SameSite=Strict (para áreas críticas)."
                ))

        return findings

    # --- 2. FORM CSRF AUDIT (SEC-006) ---
    def _audit_forms_csrf(self) -> List[Finding]:
        findings = []
        if not self.soup:
            return findings

        csrf_token_patterns = ["csrf", "token", "authenticity", "xsrf", "_token"]
        post_forms = self.soup.find_all("form", method=lambda m: m and m.strip().upper() == "POST")

        for idx, form in enumerate(post_forms):
            action = form.get("action", "") or self.base_url
            inputs = form.find_all("input")
            has_csrf_token = False

            for inp in inputs:
                name = inp.get("name", "").lower()
                if any(pat in name for pat in csrf_token_patterns):
                    has_csrf_token = True
                    break

            if not has_csrf_token:
                kb = VULNERABILITIES_KB[6]
                findings.append(Finding(
                    id=f"FORM-NO-CSRF-TOKEN-{idx+1}",
                    vuln_number=6,
                    title=f"Formulario POST sin Token Anti-CSRF Detectable (Formulario #{idx+1})",
                    category=kb["chapter"],
                    severity=Severity.MEDIUM,
                    status=FindingStatus.POTENTIAL,
                    affected_component=f"Formulario HTML action='{action}'",
                    technical_description="Se identificó un formulario HTML que envía datos mediante el método POST sin incluir campos ocultos que contengan tokens anti-CSRF aleatorios. Si la acción modifica el estado del usuario, podría ser vulnerable a Cross-Site Request Forgery.",
                    evidence=f"<form method='POST' action='{action}'> (Total campos: {len(inputs)})",
                    impact=kb["impact"],
                    remediation=kb["remediation"]
                ))
        return findings

    # --- 3. CORS MISCONFIGURATION PROBE (SEC-034) ---
    def _audit_cors_policy(self) -> List[Finding]:
        findings = []
        evil_origin = "https://evil-security-audit.example.com"
        try:
            # Probe 1: Arbitrary Origin reflection
            resp = self.requester.get("/", headers={"Origin": evil_origin}, allow_redirects=False)
            allow_origin = resp.headers.get("Access-Control-Allow-Origin", "").strip()
            allow_creds = resp.headers.get("Access-Control-Allow-Credentials", "").lower().strip()

            if allow_origin == evil_origin:
                kb = VULNERABILITIES_KB[34]
                severity = Severity.HIGH if allow_creds == "true" else Severity.MEDIUM
                findings.append(Finding(
                    id="CORS-REFLECTED-ORIGIN",
                    vuln_number=34,
                    title="CORS Inseguro: Reflejo Ciego del Encabezado Origin",
                    category=kb["chapter"],
                    severity=severity,
                    status=FindingStatus.CONFIRMED,
                    affected_component="Cabecera Access-Control-Allow-Origin",
                    technical_description=f"El servidor refleja cualquier origen recibido ({evil_origin}). " + 
                                          ("Al estar combinado con 'Access-Control-Allow-Credentials: true', cualquier sitio externo puede leer datos privados autenticados de los usuarios." if allow_creds == "true" else "Permite a sitios arbitrarios realizar lecturas de respuestas."),
                    evidence=f"Origin enviado: {evil_origin}\nRespuesta ACAO: {allow_origin}\nACAC: {allow_creds}",
                    impact=kb["impact"],
                    remediation=kb["remediation"]
                ))
            elif allow_origin == "*" and allow_creds == "true":
                kb = VULNERABILITIES_KB[34]
                findings.append(Finding(
                    id="CORS-WILDCARD-CREDS",
                    vuln_number=34,
                    title="CORS Inseguro: Comodín (*) con Credenciales Habilitadas",
                    category=kb["chapter"],
                    severity=Severity.HIGH,
                    status=FindingStatus.CONFIRMED,
                    affected_component="Cabecera Access-Control-Allow-Origin",
                    technical_description="Configuración CORS inválida o peligrosa que combina comodín universal con credenciales de usuario.",
                    evidence="ACAO: * con ACAC: true",
                    impact=kb["impact"],
                    remediation=kb["remediation"]
                ))
            
            # Probe 2: Origin: null reflection
            resp_null = self.requester.get("/", headers={"Origin": "null"}, allow_redirects=False)
            if resp_null.headers.get("Access-Control-Allow-Origin") == "null":
                kb = VULNERABILITIES_KB[34]
                findings.append(Finding(
                    id="CORS-NULL-ALLOWED",
                    vuln_number=34,
                    title="CORS Inseguro: Aceptación de Origen 'null'",
                    category=kb["chapter"],
                    severity=Severity.MEDIUM,
                    status=FindingStatus.CONFIRMED,
                    affected_component="Cabecera Access-Control-Allow-Origin: null",
                    technical_description="El servidor autoriza el origen 'null'. Esto permite a páginas en iframes sandboxed locales o documentos de esquema data: evadir las restricciones de origen cruzado.",
                    evidence="Petición con Origin: null devuelve Access-Control-Allow-Origin: null",
                    impact=kb["impact"],
                    remediation="No permitir el origen 'null' en la lista blanca de CORS."
                ))
        except Exception:
            pass
        return findings

    # --- 4. HOST HEADER INJECTION PROBE (SEC-023) ---
    def _audit_host_header(self) -> List[Finding]:
        findings = []
        canary_host = "security-audit-canary.test"
        try:
            resp = self.requester.get("/", headers={"Host": canary_host}, allow_redirects=False)
            # Check if canary is reflected in redirect location or links
            location = resp.headers.get("Location", "")
            if canary_host in location:
                kb = VULNERABILITIES_KB[23]
                findings.append(Finding(
                    id="HOST-HEADER-INJECTION-REDIRECT",
                    vuln_number=23,
                    title="Inyección de Cabecera Host en Redirección HTTP",
                    category=kb["chapter"],
                    severity=Severity.HIGH,
                    status=FindingStatus.CONFIRMED,
                    affected_component="Cabecera Host / Generación de Location",
                    technical_description=f"El servidor acepta un valor de cabecera Host arbitrario ({canary_host}) y lo utiliza directamente para componer la URL de redirección.",
                    evidence=f"Host enviado: {canary_host}\nCabecera Location obtenida: {location}",
                    impact=kb["impact"],
                    remediation=kb["remediation"]
                ))
            elif canary_host in resp.text:
                kb = VULNERABILITIES_KB[23]
                findings.append(Finding(
                    id="HOST-HEADER-REFLECTED-BODY",
                    vuln_number=23,
                    title="Reflejo de Cabecera Host en Contenido de la Página",
                    category=kb["chapter"],
                    severity=Severity.MEDIUM,
                    status=FindingStatus.CONFIRMED,
                    affected_component="Cabecera Host / Generación de Enlaces",
                    technical_description=f"El servidor refleja el valor inyectado de la cabecera Host ({canary_host}) en enlaces absolutos del cuerpo HTML. Si la página es guardada en caché, provocará envenenamiento de caché (Cache Poisoning).",
                    evidence=f"Host inyectado encontrado en el cuerpo de la respuesta ({canary_host})",
                    impact=kb["impact"],
                    remediation=kb["remediation"]
                ))
        except Exception:
            pass
        return findings

    # --- 5. CLIENT-SIDE SCRIPT AUDIT (SEC-005, SEC-097, SEC-098) ---
    def _audit_client_scripts(self) -> List[Finding]:
        findings = []
        if not self.soup:
            return findings

        # Check Subresource Integrity (SRI) on external scripts (SEC-097)
        scripts = self.soup.find_all("script")
        missing_sri_count = 0
        external_scripts = []

        for script in scripts:
            src = script.get("src", "")
            if src.startswith("http://") or src.startswith("https://") or src.startswith("//"):
                parsed = urllib.parse.urlparse(src)
                if parsed.netloc and parsed.netloc != self.host:
                    external_scripts.append(src)
                    if not script.get("integrity"):
                        missing_sri_count += 1

            # Check inline script for Prototype Pollution and dangerous DOM sinks (SEC-005, SEC-098)
            script_text = script.string or ""
            if script_text:
                # Prototype pollution indicators
                if re.search(r"(\.prototype|__proto__|constructor\[\"prototype\"\])", script_text) and \
                   re.search(r"(merge|clone|extend|deepClone|assign)\s*\(", script_text):
                    kb = VULNERABILITIES_KB[98]
                    findings.append(Finding(
                        id="CLIENT-PROTO-POLLUTION",
                        vuln_number=98,
                        title="Patrón de Riesgo de Prototype Pollution en Script del Cliente",
                        category=kb["chapter"],
                        severity=Severity.MEDIUM,
                        status=FindingStatus.POTENTIAL,
                        affected_component="Script Frontend / Manipulación de Objetos",
                        technical_description="Se detectaron funciones de clonado o fusión profunda iterando sobre prototipos sin validación previa de claves prohibidas (__proto__, constructor, prototype).",
                        evidence="Firma de extensión profunda y acceso a __proto__ en script",
                        impact=kb["impact"],
                        remediation=kb["remediation"]
                    ))

                # DOM XSS sinks (SEC-005)
                if re.search(r"(document\.write\(|eval\(|innerHTML\s*=\s*(location|window\.name|document\.URL))", script_text):
                    kb = VULNERABILITIES_KB[5]
                    findings.append(Finding(
                        id="CLIENT-DOM-XSS-SINK",
                        vuln_number=5,
                        title="Sumidero Peligroso de DOM XSS Identificado en JavaScript",
                        category=kb["chapter"],
                        severity=Severity.HIGH,
                        status=FindingStatus.POTENTIAL,
                        affected_component="Script en Línea / Sink DOM",
                        technical_description="El script del cliente escribe directamente fuentes de datos no confiables (location, hash o URL) en sumideros de ejecución activa como innerHTML, eval o document.write.",
                        evidence="Coincidencia de patrón sink peligroso en el código frontend",
                        impact=kb["impact"],
                        remediation=kb["remediation"]
                    ))

        if missing_sri_count > 0:
            kb = VULNERABILITIES_KB[97]
            findings.append(Finding(
                id="SCRIPT-MISSING-SRI",
                vuln_number=97,
                title=f"Scripts Externos sin Subresource Integrity (SRI) ({missing_sri_count} detectados)",
                category=kb["chapter"],
                severity=Severity.LOW,
                status=FindingStatus.CONFIRMED,
                affected_component=f"Etiquetas <script src='...'> externas",
                technical_description="Se cargan librerías JavaScript desde CDNs o dominios de terceros sin verificar el hash criptográfico mediante el atributo 'integrity'. Si el servidor del proveedor sufriera un compromiso, el código malicioso se ejecutaría en el sitio de forma transparente.",
                evidence=f"{missing_sri_count} scripts sin atributo integrity (ej. {external_scripts[0] if external_scripts else 'CDN'})",
                impact=kb["impact"],
                remediation="Añadir atributos integrity='sha384-...' y crossorigin='anonymous' a todas las etiquetas de script y estilo de terceros."
            ))

        return findings

    @staticmethod
    def _verify_service(ip: str, port: int) -> str:
        """Intenta confirmar el protocolo real. Devuelve 'verified', 'mismatch' o 'unknown'.
        Evita falsos positivos de firewalls/proxies que aceptan TCP en cualquier puerto."""
        try:
            sk = socket.create_connection((ip, port), timeout=2.0)
            sk.settimeout(2.0)
            try:
                if port in (21, 22, 3306):          # el servidor habla primero
                    banner = sk.recv(64)
                    if port == 21:
                        return "verified" if banner.startswith(b"220") else "mismatch"
                    if port == 22:
                        return "verified" if banner.startswith(b"SSH-") else "mismatch"
                    # MySQL: paquete de saludo con byte de protocolo 0x0a o paquete de error de host bloqueado
                    return "verified" if len(banner) > 5 and (banner[4] in (0x0a, 0xff)) else "mismatch"
                if port == 5432:                    # SSLRequest: PostgreSQL responde 'S' o 'N'
                    sk.sendall(b"\x00\x00\x00\x08\x04\xd2\x16\x2f")
                    return "verified" if sk.recv(1) in (b"S", b"N") else "mismatch"
                if port == 6379:                    # PING: +PONG o -NOAUTH
                    sk.sendall(b"PING\r\n")
                    r = sk.recv(32)
                    return "verified" if r.startswith((b"+PONG", b"-NOAUTH", b"-DENIED", b"-ERR")) else "mismatch"
            finally:
                sk.close()
        except Exception:
            return "unknown"
        return "unknown"

    # --- 6. EXPOSED DATABASE & ADMIN PORTS (SEC-051, 052, 053, 054, 055, 089, 090, 091) ---
    def _check_exposed_service_ports(self) -> List[Finding]:
        """Performs non-intrusive TCP socket connection checks with a short timeout."""
        findings = []
        port_services = [
            (3306, 51, "Servicio MySQL / MariaDB Expuesto Públicamente (Puerto 3306)", Severity.HIGH, "Base de Datos MySQL"),
            (5432, 52, "Servicio PostgreSQL Expuesto Públicamente (Puerto 5432)", Severity.HIGH, "Base de Datos PostgreSQL"),
            (27017, 53, "Servicio MongoDB Expuesto Públicamente (Puerto 27017)", Severity.CRITICAL, "Base de Datos NoSQL MongoDB"),
            (6379, 54, "Servicio Redis Expuesto Públicamente (Puerto 6379)", Severity.CRITICAL, "Almacén en Memoria Redis"),
            (9200, 55, "API Elasticsearch Expuesta Públicamente (Puerto 9200)", Severity.HIGH, "Motor de Búsqueda Elasticsearch"),
            (21, 89, "Servicio FTP Abierto a Internet (Puerto 21)", Severity.MEDIUM, "Servidor de Transferencia FTP"),
            (22, 90, "Servicio SSH Accesible Directamente (Puerto 22)", Severity.LOW, "Administración SSH"),
            (3389, 91, "Servicio RDP de Escritorio Remoto Expuesto (Puerto 3389)", Severity.HIGH, "Administración RDP")
        ]

        # Resolve IP for the target host
        try:
            ip_addr = socket.gethostbyname(self.host)
        except Exception:
            return findings

        for port, vuln_num, title, sev, comp in port_services:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1.2) # Very short non-intrusive timeout
            try:
                result = sock.connect_ex((ip_addr, port))
                if result == 0:
                    kb = VULNERABILITIES_KB.get(vuln_num, {})
                    verdict = self._verify_service(ip_addr, port)
                    if verdict == "mismatch":
                        continue  # el puerto acepta TCP pero no habla el protocolo esperado (proxy/firewall)
                    findings.append(Finding(
                        id=f"PORT-EXPOSED-{port}",
                        vuln_number=vuln_num,
                        title=title,
                        category=kb.get("chapter", "Infraestructura y Red"),
                        severity=sev,
                        status=FindingStatus.CONFIRMED if verdict == "verified" else FindingStatus.POTENTIAL,
                        affected_component=f"{comp} (IP: {ip_addr}:{port})",
                        technical_description=f"El puerto de red {port} ({comp}) responde a conexiones TCP externas sin estar protegido por un cortafuegos perimetral.",
                        evidence=f"Conexión TCP establecida con {ip_addr}:{port}. Protocolo " + ("verificado por banner/handshake." if verdict == "verified" else "no verificable (solo TCP abierto)."),
                        impact=kb.get("impact", "Exposición de servicios administrativos o de datos."),
                        remediation=kb.get("remediation", "Bloquear el puerto en el firewall del host o de la nube.")
                    ))
            except Exception:
                pass
            finally:
                sock.close()

        return findings
