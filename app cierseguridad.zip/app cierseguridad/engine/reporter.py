"""
Report Generator Module.
Generates comprehensive JSON reports and standalone Dark/Print-ready HTML/PDF reports.
"""
import json
import os
from engine.models import AuditReport

class ReportGenerator:
    def __init__(self, output_dir: str = "reports"):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)

    def export_json(self, report: AuditReport) -> str:
        filepath = os.path.join(self.output_dir, f"{report.scan_id}.json")
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(report.to_dict(), f, indent=2, ensure_ascii=False)
        return filepath

    def export_html(self, report: AuditReport) -> str:
        filepath = os.path.join(self.output_dir, f"{report.scan_id}.html")
        html = self._render_html_template(report)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html)
        return filepath

    def _render_html_template(self, report: AuditReport) -> str:
        rep_dict = report.to_dict()
        summary = rep_dict["summary"]
        counts = summary.get("counts", {})
        score = summary.get("security_score", 100)
        score_color = "#ef4444" if score < 50 else ("#f59e0b" if score < 80 else "#10b981")

        # Render tech rows
        tech_html = ""
        for t in rep_dict.get("technologies", []):
            ver = f"<span class='badge-ver'>{t['version']}</span>" if t.get('version') else ""
            tech_html += f"""
            <div class="tech-card">
                <div class="tech-name">{t['name']} {ver}</div>
                <div class="tech-cat">{t['category']}</div>
                <div class="tech-ev">{t.get('evidence', '')}</div>
            </div>
            """

        # Render findings
        findings_html = ""
        for f in rep_dict.get("findings", []):
            sev_class = f"sev-{f['severity'].lower()}"
            status_badge = f"<span class='status-pill'>{f['status']}</span>"
            findings_html += f"""
            <div class="finding-card {sev_class}">
                <div class="finding-header">
                    <span class="finding-sev">{f['severity']}</span>
                    <span class="finding-title">#{f['vuln_number']} {f['title']}</span>
                    {status_badge}
                </div>
                <div class="finding-meta">
                    <strong>Componente Afectado:</strong> <code>{f['affected_component']}</code> | 
                    <strong>Categoría:</strong> {f['category']}
                </div>
                <div class="finding-desc">
                    <p>{f['technical_description']}</p>
                </div>
                <div class="finding-evidence">
                    <strong>Evidencia Técnica:</strong>
                    <pre>{f['evidence']}</pre>
                </div>
                <div class="finding-remed">
                    <strong>Recomendación de Mitigación:</strong>
                    <p>{f['remediation']}</p>
                </div>
            </div>
            """

        return f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Auditoría de Ciberseguridad - {report.domain}</title>
    <style>
        :root {{
            --bg-dark: #0a0e17;
            --card-bg: #111827;
            --border-color: #1f2937;
            --text-primary: #f3f4f6;
            --text-secondary: #9ca3af;
            --accent: #38bdf8;
            --crit: #ef4444;
            --high: #f97316;
            --med: #eab308;
            --low: #3b82f6;
            --info: #6b7280;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-primary);
            margin: 0;
            padding: 30px;
            line-height: 1.5;
        }}
        .header {{
            border-bottom: 2px solid var(--border-color);
            padding-bottom: 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .logo {{
            font-size: 24px;
            font-weight: 800;
            letter-spacing: -0.5px;
            color: var(--accent);
        }}
        .score-box {{
            background: var(--card-bg);
            border: 2px solid {score_color};
            padding: 15px 25px;
            border-radius: 12px;
            text-align: center;
        }}
        .score-val {{
            font-size: 36px;
            font-weight: 900;
            color: {score_color};
        }}
        .score-label {{
            font-size: 11px;
            color: var(--text-secondary);
            text-transform: uppercase;
        }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 15px;
        }}
        .stat-val {{
            font-size: 26px;
            font-weight: 700;
        }}
        .stat-name {{
            font-size: 12px;
            color: var(--text-secondary);
            text-transform: uppercase;
        }}
        .section-title {{
            font-size: 18px;
            font-weight: 700;
            color: var(--accent);
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 8px;
            margin-top: 40px;
            margin-bottom: 20px;
        }}
        .tech-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 15px;
        }}
        .tech-card {{
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            padding: 12px;
            border-radius: 8px;
        }}
        .tech-name {{
            font-weight: 600;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .badge-ver {{
            background: #1e293b;
            color: var(--accent);
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 11px;
        }}
        .tech-cat {{
            color: var(--text-secondary);
            font-size: 12px;
            margin: 4px 0;
        }}
        .tech-ev {{
            font-size: 11px;
            color: #64748b;
            word-break: break-all;
        }}
        .finding-card {{
            background: var(--card-bg);
            border-left: 5px solid var(--info);
            border-radius: 8px;
            padding: 18px;
            margin-bottom: 20px;
            border-top: 1px solid var(--border-color);
            border-right: 1px solid var(--border-color);
            border-bottom: 1px solid var(--border-color);
        }}
        .sev-crítica {{ border-left-color: var(--crit); }}
        .sev-alta {{ border-left-color: var(--high); }}
        .sev-media {{ border-left-color: var(--med); }}
        .sev-baja {{ border-left-color: var(--low); }}
        .sev-información {{ border-left-color: var(--info); }}
        .finding-header {{
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 10px;
        }}
        .finding-sev {{
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            padding: 3px 8px;
            border-radius: 4px;
            background: #1f2937;
        }}
        .finding-title {{
            font-size: 16px;
            font-weight: 700;
        }}
        .status-pill {{
            margin-left: auto;
            font-size: 10px;
            font-weight: 600;
            background: #1e293b;
            padding: 3px 8px;
            border-radius: 12px;
            color: var(--text-secondary);
        }}
        .finding-meta {{
            font-size: 12px;
            color: var(--text-secondary);
            margin-bottom: 12px;
        }}
        .finding-evidence pre {{
            background: #030712;
            padding: 10px;
            border-radius: 6px;
            font-family: monospace;
            font-size: 12px;
            overflow-x: auto;
            color: #38bdf8;
            margin: 8px 0;
        }}
        .finding-remed {{
            background: rgba(16, 185, 129, 0.08);
            border: 1px solid rgba(16, 185, 129, 0.2);
            padding: 12px;
            border-radius: 6px;
            margin-top: 12px;
            font-size: 13px;
        }}
        @media print {{
            body {{ background-color: #fff; color: #000; padding: 10px; }}
            .header {{ border-color: #ccc; }}
            .score-box, .stat-card, .tech-card, .finding-card {{ background: #f9f9f9; border-color: #ddd; color: #000; }}
            .finding-evidence pre {{ background: #f0f0f0; color: #000; }}
            .finding-remed {{ background: #f0fdf4; border-color: #86efac; color: #000; }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <div>
            <div class="logo">⚡ CYBERSEC AUDIT ENGINE</div>
            <div style="color: var(--text-secondary); font-size: 13px; margin-top: 5px;">
                Auditoría Técnica de Sitios Web y Servidores | RFC 9110 Safe Standards
            </div>
            <div style="font-size: 14px; margin-top: 8px;">
                <strong>Objetivo:</strong> <code>{report.target_url}</code> | <strong>Fecha:</strong> {report.start_time} | <strong>Duración:</strong> {report.duration_seconds:.2f}s
            </div>
        </div>
        <div class="score-box">
            <div class="score-val">{score}</div>
            <div class="score-label">Score de Seguridad</div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-val" style="color: var(--crit);">{counts.get('critical', 0)}</div>
            <div class="stat-name">Críticas</div>
        </div>
        <div class="stat-card">
            <div class="stat-val" style="color: var(--high);">{counts.get('high', 0)}</div>
            <div class="stat-name">Altas</div>
        </div>
        <div class="stat-card">
            <div class="stat-val" style="color: var(--med);">{counts.get('medium', 0)}</div>
            <div class="stat-name">Medias</div>
        </div>
        <div class="stat-card">
            <div class="stat-val" style="color: var(--low);">{counts.get('low', 0)}</div>
            <div class="stat-name">Bajas</div>
        </div>
        <div class="stat-card">
            <div class="stat-val" style="color: var(--accent);">{counts.get('confirmed', 0)}</div>
            <div class="stat-name">Confirmadas</div>
        </div>
        <div class="stat-card">
            <div class="stat-val" style="color: #a855f7;">{len(rep_dict.get('technologies', []))}</div>
            <div class="stat-name">Tecnologías</div>
        </div>
    </div>

    <div class="section-title">Tecnologías y Componentes Detectados</div>
    <div class="tech-grid">
        {tech_html if tech_html else "<p>No se identificaron tecnologías específicas en las respuestas analizadas.</p>"}
    </div>

    <div class="section-title">Hallazgos y Vulnerabilidades ({len(rep_dict.get('findings', []))})</div>
    <div class="findings-list">
        {findings_html if findings_html else "<p>No se detectaron debilidades conocidas en las pruebas ejecutadas.</p>"}
    </div>
</body>
</html>"""
