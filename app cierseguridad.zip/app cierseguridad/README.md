# ⚡ CyberSec Audit Engine - Plataforma de Auditoría Técnica y Ciberseguridad

Aplicación modular de escritorio y web diseñada para la **auditoría técnica y análisis de seguridad defensivo** sobre sitios web, aplicaciones e infraestructura de servidores. Desarrollada para uso educativo, laboratorios y auditorías autorizadas bajo estándares RFC 9110 y guías OWASP WSTG.

---

## 🚀 Inicio Rápido

### 1. Requisitos Previos
- Python 3.10 o superior (instalado en el sistema).
- Dependencias incluidas: `Flask`, `requests`, `beautifulsoup4`, `dnspython`.

Para instalar dependencias en cualquier equipo nuevo:
```bash
pip install -r requirements.txt
```

### 2. Ejecutar la Aplicación
Hacer doble clic en `run.bat` o ejecutar en terminal:
```bash
python app.py
```
Abrir el navegador web en: **`http://127.0.0.1:5000`**

---

## 🛠️ Arquitectura Técnica y Modular

El motor de análisis se diseñó siguiendo una separación estricta de responsabilidades:

```
app_cierseguridad/
├── app.py                      # Servidor Flask, API REST y streaming SSE
├── run.bat                     # Lanzador rápido para Windows
├── test_scan.py                # Script de prueba y validación del motor
├── engine/                     # MOTOR CENTRAL DE ANÁLISIS
│   ├── models.py               # Modelos estructurados (Finding, AuditReport, TechFingerprint)
│   ├── scope.py                # Gestión de alcance, token bucket rate limiter y barrera anti-SSRF
│   ├── logger.py               # Cola thread-safe con difusión en tiempo real vía Server-Sent Events
│   ├── knowledge_base.py       # Catálogo de las 100 familias de vulnerabilidades (CWE, OWASP, mitigaciones)
│   ├── tls_analyzer.py         # Análisis de certificados X.509, suites de cifrado, HSTS y protocolos obsoletos
│   ├── headers_analyzer.py     # Inspección exhaustiva de cabeceras de seguridad HTTP y fugas de información
│   ├── fingerprint.py          # Reconocimiento de servidores, SO, CMS y frameworks + cotejo de CVEs conocidos
│   ├── exposure_scanner.py     # Detección controlada de archivos sensibles (.env, .git, backups, server-status, graphql) con anti-Soft-404
│   ├── web_checks.py           # Verificación segura de Cookies, CORS mal configurado, Host Header, scripts DOM y puertos
│   ├── dns_analyzer.py         # Inspección de SPF, DMARC, transferencias de zona (AXFR) y CNAME
│   ├── scanner.py              # Orquestador del ciclo de vida del análisis y cálculo de Security Score
│   └── reporter.py             # Generador de reportes en JSON y reportes HTML/PDF listos para impresión
├── static/
│   ├── css/style.css           # Interfaz Cyber Dark Theme con paleta profesional de ciberseguridad
│   └── js/app.js               # Controlador interactivo, cliente SSE, filtros en tiempo real y modales
├── templates/
│   └── index.html              # Dashboard principal (Centro de mando de auditoría)
└── reports/                    # Directorio de persistencia de reportes JSON y HTML exportados
```

---

## 🛡️ Principios Éticos y Mecanismos de Seguridad Activa

1. **Restricción de Alcance y Protección contra Redirecciones (Redirect Guard)**:
   - Toda solicitud se valida contra el dominio base autorizado.
   - Si un endpoint responde con una redirección HTTP externa hacia un tercero no autorizado, la solicitud es bloqueada inmediatamente para evitar SSRF o auditorías accidentales fuera de alcance.
2. **Control Estricto de Concurrencia (Rate Limiting)**:
   - Token bucket configurado por defecto a **3 req/s** (ajustable a 1 req/s para sigilo o 5 req/s para laboratorios locales), protegiendo la disponibilidad del objetivo.
3. **Eliminación de Falsos Positivos (Anti-Soft-404)**:
   - El escáner perfila las respuestas de error del servidor antes de auditar rutas sensibles (`/.env`, `/.git/HEAD`, etc.) y aplica validadores contextuales estrictos (patrones regex y tipos de contenido) en lugar de fiarse ciegamente de códigos HTTP 200.
4. **Verificación No Destructiva**:
   - No se realizan inyecciones con alteración de base de datos, extracción de datos privados de usuarios ni ataques de denegación de servicio.
5. **Diferenciación de Hallazgos**:
   - **CONFIRMADA**: Evidencia inequívoca observada directamente en respuestas HTTP, certificados o puertos abiertos.
   - **POTENCIAL**: Indicios sólidos (por ejemplo, formularios POST sin tokens anti-CSRF visibles o frameworks desactualizados).
   - **REQUIERE_VALIDACION**: Familias complejas (BOLA, IDOR, Race Conditions, Stored XSS) que requieren credenciales multi-usuario o pruebas en laboratorio para no poner en riesgo la producción.

---

## 📊 Sistema de Reportes

- **Consola Terminal en Vivo**: Salida con marcas de tiempo y niveles `[INFO]`, `[PHASE]`, `[SUCCESS]`, `[WARN]`, `[ERROR]`.
- **Panel de Métricas**: Puntuación de Seguridad (0 a 100), conteo por severidad (*Crítica, Alta, Media, Baja, Informativa*).
- **Exportación en JSON**: Contiene el objeto completo del análisis para integración en pipelines o herramientas SIEM.
- **Reporte Imprimible HTML / PDF**: Plantilla optimizada con estilos de impresión `@media print` para exportar a PDF con un clic (`Ctrl + P` -> Guardar como PDF).

---

## 🆕 Cambios de esta versión (v2): por qué ahora SÍ detecta vulnerabilidades

La versión anterior solo analizaba la página principal (`/`): cabeceras, TLS, DNS, cookies y archivos expuestos. **Nunca rastreaba el sitio, nunca iniciaba sesión y nunca enviaba pruebas de inyección**; para SQLi/XSS solo agregaba una nota de "verificación manual". Por eso en apps vulnerables como bWAPP o DVWA solo veía hallazgos menores.

**Nuevo**
- `engine/crawler.py`: rastrea el sitio (profundidad y páginas configurables), descubre URLs con parámetros y formularios, usa `sitemap.xml`, evita enlaces de logout/delete y avisa si el sitio parece una SPA.
- `engine/injection_checks.py`: pruebas de **detección** no destructivas: XSS reflejado, SQLi por errores (y diferencia booleana como "potencial") y Open Redirect.
- **Autenticación**: cookie de sesión, cabeceras (`Authorization: Bearer ...`) o login automático por formulario (copia tokens ocultos tipo `user_token` de DVWA).
- **URLs semilla**: para SPAs y APIs (ej. `/rest/products/search?q=test` en Juice Shop).
- Opciones avanzadas en la UI y `lab/vuln_lab.py` + `test_lab.py` para validar el motor en local.

**Bugs corregidos**
- Los logs de escaneos anteriores se mezclaban en cada reporte nuevo.
- Si el sitio no respondía, el reporte decía 86/100 "ACEPTABLE". Ahora se marca **INCOMPLETO**.
- `www.sitio.com` ↔ `sitio.com` se consideraba fuera de alcance al seguir redirecciones.
- Timeouts: un reintento automático con el doble de tiempo.
- Los puertos "expuestos" (MySQL, PostgreSQL, FTP, SSH, Redis) ahora se verifican por banner/handshake; si solo hay TCP abierto queda como POTENCIAL.
- Dos clics rápidos podían lanzar dos escaneos a la vez.

**Cómo probarlo**
```bash
python lab/vuln_lab.py        # terminal 1: laboratorio vulnerable en 127.0.0.1:5001 (admin / admin)
python test_lab.py            # terminal 2: debe reportar XSS, SQLi y Open Redirect
```
Para DVWA: poné la URL, en *Opciones avanzadas* la URL de login (`.../login.php`), usuario `admin`, clave `password`,
y en DVWA Security el nivel **Low**. Las pruebas activas y POST solo contra sistemas propios o con autorización escrita.

**Límites honestos**: no detecta lógica de negocio, IDOR/BOLA, XSS almacenado, SQLi ciega por tiempo ni DOM XSS dinámico (requiere navegador). Para eso se complementa con OWASP ZAP / Burp.


## Actualización v2.1 — estabilidad y auditorías adicionales

- Reemplazado el cliente HTTP: reintentos acotados para GET/HEAD/OPTIONS, backoff exponencial, timeout configurable y cierre de sesión.
- Validación de URL HTTP/HTTPS, hostname y redirecciones dentro del alcance.
- Límite de velocidad con sincronización y plazo máximo aplicado a las solicitudes HTTP.
- Los identificadores de análisis ahora incluyen fecha, hora y sufijo aleatorio para evitar colisiones.
- Añadidas comprobaciones pasivas de `Permissions-Policy`, `Referrer-Policy`, caché en rutas potencialmente sensibles y divulgación de versión en `Server`.
- El dashboard permite seleccionar hasta 20 solicitudes/s en loopback; para destinos públicos el servidor limita el máximo a 3 solicitudes/s.
- Profundidad y cantidad de páginas predeterminadas mayores para laboratorios locales.

### Alcance de las pruebas
La herramienta conserva el consentimiento explícito, la validación de alcance y el bloqueo de redirecciones a terceros. Las pruebas automáticas siguen siendo no destructivas; no se agregaron cargas de explotación, extracción de datos ni pruebas de denegación de servicio. El límite de duración controla las solicitudes HTTP del motor; tareas externas de DNS/TLS pueden terminar después de ese plazo.

### Instalación / actualización
```bash
python -m pip install -r requirements.txt
python app.py
```
Abrir `http://127.0.0.1:5000`. En Windows también se puede ejecutar `run.bat`.


## 🆕 Catálogo ampliado v3.0 — 300 familias

La taxonomía ahora incluye 300 entradas organizadas en APIs/autorización, identidad y sesiones, inyección web, configuración, cloud/containers, DNS/TLS/correo, supply chain, lógica de negocio, infraestructura y privacidad/frontend.

**Importante:** el catálogo es una referencia para el motor y para revisión manual; no significa que las 300 familias se detecten automáticamente. Los análisis automáticos actuales conservan sus pruebas seguras implementadas. Los casos que requieren credenciales de distintos roles, acceso a configuración/código, pruebas especializadas o condiciones de negocio deben informarse como potenciales o pendientes de validación, sin afirmar una confirmación no respaldada por evidencia.

Uso exclusivo en activos propios o con autorización explícita. No se incluyen pruebas destructivas, extracción de datos, fuerza bruta ni denegación de servicio.
